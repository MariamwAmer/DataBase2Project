import java.io.Serializable;


public class NULL implements Serializable{
	
	public String toString(){
		return "NULL";
	}

}
