import java.io.Serializable;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;


public class Key implements Serializable {

//	private Page page;
//	private Object ck;
	private Point point;
	//private Hashtable<Object, Page> tuples = new Hashtable<Object, Page>();		//for duplicates
	private Hashtable<String, Vector> pageTuples = new Hashtable<String, Vector>();		//for duplicates

	private Vector CKs = new Vector();
	
	public Key(Page page, Object ck, Point p){
		//this.page = page;
		
		//this.ck = ck;
		insertTuple(page.getPageName(), ck);
		
//		Vector tuples = new Vector();
//		tuples.add(ck);
//		
//		pageTuples.put(page, tuples);
		
		this.point = p;
	}
	
	public void insertTuple(String pageName, Object ck){
		
		if(pageTuples.containsKey(pageName)){
			Vector tuples = pageTuples.get(pageName);
			tuples.add(ck);
		}
		
		else{
			Vector tuples = new Vector();
			tuples.add(ck);
			
			pageTuples.put(pageName, tuples);
		}
		
		CKs.add(ck);
		//tuples.put(ck, page);
	}

	public Point getPoint() {
		return point;
	}

	public void setPoint(Point point) {
		this.point = point;
	}

	
	
	public Hashtable<String, Vector> getPageTuples() {
		return pageTuples;
	}

	public void setPageTuples(Hashtable<String, Vector> pageTuples) {
		this.pageTuples = pageTuples;
	}

	public String toString(){
		return point.toString() + " (" + pageTuples + ")";
		
	}
	
	public boolean contains(Object ck){
		return CKs.contains(ck);
	}
	
	public String getPageName(Object ck){
		Enumeration e = pageTuples.keys();
		
		while(e.hasMoreElements()){
			
			String pageName = (String) e.nextElement();
			
			Vector tuplesOfPage = pageTuples.get(pageName);
			
			if(tuplesOfPage.contains(ck))
				return pageName;
		}
		return "";
	}
	
	
}
