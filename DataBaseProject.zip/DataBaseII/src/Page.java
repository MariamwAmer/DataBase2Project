import java.io.*;
import java.util.*;


public class Page  implements Serializable {
	
	
	private Vector tuplesInPage = new Vector ();
	private Table table;
	//private static int pageCount;
	private String pageName;
	private Object pageMin;
	private Object pageMax;
	private int MaximumRowsinPage;
	private String path;
	
	public Page(Table table){
		this.table = table;
		//pageCount++;
		pageName = "Page " + (table.getPages().size()+1);
		path = "resources/data/" + table.getTablename() + "/" + pageName + ".ser";
		
		Properties prop = new Properties();
		String fileName = "resources/DBApp.config";
		try (FileInputStream file = new FileInputStream(fileName)) {
		    prop.load(file);
		} catch (FileNotFoundException ex) {
                  
		} catch (IOException ex) {
		    
		}
		
		MaximumRowsinPage=Integer.parseInt(prop.getProperty("MaximumRowsCountinTablePage"));
		
		//MaximumRowsinPage = 3;
	}
	
	
	public Vector<Hashtable> getTuplesinpage() {
		return tuplesInPage;
	}
	
	public void setTuplesinpage(Vector<Hashtable> tuplesinpage) {
		this.tuplesInPage = tuplesinpage;
	}
	
	public Table getTable() {
		return table;
	}
	
	public void setTable(Table tablename) {
		this.table = tablename;
	}
	
	public String getPageName() {
		return pageName;
	}
	
	public void setPageid(String pageName) {
		this.pageName = pageName;
	}
	
	public Object getPagemin() {
		return pageMin;
	}
	
	public void setPagemin(Object pagemin) {
		this.pageMin = pagemin;
	}
	
	public Object getPagemax() {
		return pageMax;
	}
	
	public void setPagemax(Object pagemax) {
		this.pageMax = pagemax;
	}
	
	
	public int getMaximumRowsinPage() {
		return MaximumRowsinPage;
	}


	public void setMaximumRowsinPage(int maximumRowsinPage) {
		MaximumRowsinPage = maximumRowsinPage;
	}

	public String getPath() {
		return path;
	}


	public void setPath(String path) {
		this.path = path;
	}


	public static void serialize(Page p){
		try {
			
			File f = new File(p.getPath());
			 boolean exists = false;
			 if(f.exists())
				 exists = true;
			
			//String filePath = "resources/data/" + p.getTable().getTablename() + "/" + p.getPageName() + ".ser";
	         FileOutputStream fileOut =
	         new FileOutputStream(p.getPath());
	         ObjectOutputStream out = new ObjectOutputStream(fileOut);
	         out.writeObject(p);
	         out.close();
	         fileOut.close();
	         if(!exists)
	        	 System.out.printf("Serialized page is saved in " + p.getPath() + "\n");
	      } catch (IOException i) {
	         i.printStackTrace();
	      }
	}
	
	
	public static Page deserialize(File serializedFile) {
	    Page page;
	    if (!serializedFile.exists() || !serializedFile.canRead()) {
	        return null;
	    }
	    try {
	        //use buffering
	        InputStream file = new FileInputStream(serializedFile);
	        InputStream buffer = new BufferedInputStream(file);
	        ObjectInput input = new ObjectInputStream(buffer);
	        try {
	            //deserialize the List
	            page = (Page) input.readObject();
	        } finally {
	            input.close();
	        }
	    } catch (ClassNotFoundException ex) {
	        ex.printStackTrace();
	        return null;
	    } catch (IOException ex) {
	        ex.printStackTrace();
	        return null;
	    }

	    return page;
	}
	
	
//	public static void deserialize(Page p){
//	  try {
//		//String filePath = "resources/data/" + p.getTable().getTablename() + "/" + p.getPageName() + ".ser";
//
//          FileInputStream fileIn = new FileInputStream(p.getPath());
//          ObjectInputStream in = new ObjectInputStream(fileIn);
//          p = (Page) in.readObject();
//          in.close();
//          fileIn.close();
//         // return p;
//       } catch (IOException i) {
//          i.printStackTrace();
//          return ;
//       } catch (ClassNotFoundException c) {
//          System.out.println("Page class not found");
//          c.printStackTrace();
//          return ;
//       }
//	}
	
	
	public boolean isFull(){
		return tuplesInPage.size() == MaximumRowsinPage;
	}
	
	public boolean isEmpty(){
		return tuplesInPage.size() == 0;
	}
	
	public String display(){
		return getTuplesinpage().toString() + "\n" + 
				"min = " + pageMin + ", max = " + pageMax;
	}
	
	public void updateMaxMin(String ck){
		pageMin = (getTuplesinpage().firstElement()).get(ck);
		pageMax = (getTuplesinpage().lastElement()).get(ck);
	}
	
//	public void deleteTuple(Object ck){
//		
//		String ckName = table.getClusterKey();
//		
//		Vector CKs = new Vector();
//		
//	
//		
//	}
	
	
	

	public Page loadPage(){
		Page p = deserialize(new File(this.getPath()));
		System.out.println(table.getTablename() + " " + pageName + " loaded \n");
		return p;

	}
	
	public void savePage(){
		serialize(this);
		System.out.println(table.getTablename() + " " + pageName + " saved \n");

	}
	
	public void createPage(){
		table.getPages().add(this);
		//System.out.println(table.getPages());
		serialize(this);
		System.out.println(table.getTablename() + " " + pageName + " created \n");
	}
	
	public void clearPage(){
		tuplesInPage.clear();
		pageMin = null;
		pageMax = null;
	}
	
	public void deletePage(){
		//String filePath = "resources/data/" + getTable().getTablename() + "/" + getPageName() + ".ser";
		//table.getPages().remove(this);
		File file = new File(getPath());
		
		if(file.delete()){
			System.out.println(getTable().getTablename() + " " + getPageName() + " deleted \n");
		}
		else{
			System.out.println("Failed to delete " + getTable().getTablename() + " " + getPageName());

		}
	}
	
	
	
	
	
}
