import java.io.*;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import javafx.util.Pair;



public class DBApp extends DBAppException  {
	
	
	private static Vector <Table> tables = new <Table> Vector();
	
	public DBApp(){
		
	}
	
	public void init(){
		
	}
	
	public static void createFolder(String strTableName) throws DBAppException{
		String folderPath = "resources/data/" + strTableName;
		File file = new File(folderPath);
		boolean bool = file.mkdir();
		if(bool){
			System.out.println("Table " + strTableName + " created successfully");
		}
		else{
			throw new DBAppException("Error creating table directory. Table with the same name might already exist");
		}
	}
	
	
	public void createTable(String strTableName, String strClusteringKeyColumn, 
			Hashtable<String,String> htblColNameType, 
			Hashtable<String,String> htblColNameMin, 
			Hashtable<String,String> htblColNameMax ) throws DBAppException{
		
		//strTableName = strTableName.toLowerCase();
		//strClusteringKeyColumn = strClusteringKeyColumn.toLowerCase();
		
		
		if (exists(strTableName)==true) {
			throw new DBAppException("There's a table with the same name!");
		}
		
		if(htblColNameType.size() != htblColNameMin.size()){
			throw new DBAppException("There may be missing min value entries");
		}
		
		if(htblColNameType.size() != htblColNameMax.size()){
			throw new DBAppException("There may be missing max value entries");
		}
		
		else{
			createFolder(strTableName);
			Table table = new Table(strTableName,strClusteringKeyColumn,htblColNameType,htblColNameMin,htblColNameMax);
			FileWriter fwriter;
			
			try {
				fwriter = new FileWriter(new File("resources/metadata.csv") , true);
				PrintWriter writer = new PrintWriter(fwriter);
				
				Enumeration htblColNameEnum = htblColNameType.keys();
				
				
				for (int j=0; j < htblColNameType.size();j++){
					 String s=null;
					 writer.print(strTableName + ",");
					 if(htblColNameEnum.hasMoreElements()){
						 
					     s=(String)htblColNameEnum.nextElement();
					    
					     writer.print(s + ",");
					     }
					 
					 String colType = (String)htblColNameType.get(s);
					 
					 if(!check4Types(colType)){
						 throw new DBAppException("Unsupported Data Type");
					 }
					 
					 
					 writer.print(colType +",");
					 if(s.equals(strClusteringKeyColumn)){
						 writer.print("True"  + ",");
					 }
					 else 
						 writer.print("False" + ","); 
					 
					 writer.print("null" +",");
					 writer.print("null" +",");
					 
					 writer.print((String)htblColNameMin.get(s) +",");
					 writer.print((String)htblColNameMax.get(s));
					
					 writer.print("\n");
	
				 }
	
				 writer.close();
				
			
			} catch (IOException e) {
				throw new DBAppException(" Error occurred while writing in metadata file ");
				//e.printStackTrace();
			}
			
			tables.add(table);
				
			table.saveTable();
		}
		
	}
	
	
	
	public void insertIntoTable(String strTableName, Hashtable<String,Object> htblColNameValue) throws DBAppException{
		
		//boolean tableExists = exists(strTableName);
		
		//System.out.println(htblColNameValue);
		
		//strTableName = strTableName.toLowerCase();
		
		if(!exists(strTableName)){
			throw new DBAppException("This table doesn't exist");
		}
		
		System.out.println(strTableName + " Table Found \n");
		
		System.out.println("fetching table...");
		
		Table table = getTable(strTableName);
		table = table.loadTable();
		
		//Hashtable <Table,Object> tuple = createTuple(table, htblColNameValue);	//leh <table, object>
	
		Hashtable <String,Object> tuple = createTuple(table, htblColNameValue);	
	
		
		String clusterKey = table.getClusterkey();
		Object ckValue = htblColNameValue.get(clusterKey);
		
		//int i = 0;
		Vector <Page> pages = table.getPages(); //to access all pages for this table
		//Page page = null;  //to store pages that i will edit in it
		
//		if(pages.size() == 0){		//if table is empty/
//			page = new Page(strTableName);		//create new page
//			table.getPages().add(page);
//			insertInPage(page, tuple);		//add tuple in page
//		}
	
		//else{
			Page page = findPagetoInsert(table, tuple);
			//int pageIndex = getPageIndex(page);
			//System.out.println(pageIndex);
			shiftTuples(table, page, tuple);
			
			
			for(int i = 0; i< table.getIndices().size(); i++){
				Octree index = table.getIndices().get(i);
				index = index.loadIndex();
				
				index.insert(page, tuple);
				
				index.saveIndex();
			}
			
			//table.loadTable();
			
			//System.out.println(table.getPages());
			
			table.saveTable();
			
			//page.savePage();
			
//			for(i = 0; i < table.getPages().size(); i++){
//				if(ckValue.compareTo(pages.get(i).getPagemin()) < 0){		//ck with page range
//					
//					page = pages.get(i);  /////////////////////////////////////////////////////load page
//					pages.remove(i);   //??
//					break;
//				}
//			}
//			
//			if(page.isFull()){
//				Page nextPage = pages.get(i++);
//				while(i < table.getPages().size()-1 && nextPage.isFull()){
//					nextPage = pages.get(i++);	//get next page until page is not full;
//				}
//				if(nextPage.isFull()){	//at last page and full
//					pages.add(new Page(strTableName));
//				}
//			}
	//	}
			
	}
	
	
	
	public void updateTable(String strTableName, String strClusteringKeyValue, Hashtable<String,Object> htblColNameValue ) 
			throws DBAppException{
		
		if(!exists(strTableName)){
			throw new DBAppException("This table doesn't exist");
		}
		
		Table table = getTable(strTableName);
		table = table.loadTable();
		
		String ck = table.getClusterkey();

		
		
		Vector <Page> pages = table.getPages();
		
		//Page p = pages.get(0);
		Hashtable htblColNameType = table.getHtblColNameTypes();
		
		Object ckValue = stringToObj(strClusteringKeyValue,(String)(htblColNameType.get(ck)));
		
		checkForUpdate(table, htblColNameValue);
		
		Pair<Integer, Integer> indices = findTupleIndex(table, ckValue);
		
		if(indices != null && indices.getValue() >= 0){
		
			int pageIndex = indices.getKey();
			int tupleIndex = indices.getValue();
			
			//System.out.println(pageIndex + "  " + tupleIndex );
			
			System.out.println("updating page...");
			
			Page p = table.getPages().get(pageIndex).loadPage();	//load page containing tuple
			Hashtable tuple = p.getTuplesinpage().get(tupleIndex);		//get tuple to be updated
			Hashtable oldTuple = (Hashtable) tuple.clone();
			
			Enumeration toUpdate = htblColNameValue.keys();
			
			while(toUpdate.hasMoreElements()){
				
				String attribute = (String) toUpdate.nextElement();	//get next attribute to update
				
				tuple.replace(attribute, htblColNameValue.get(attribute));
			}
			
			table.updateIndexTuple(p, oldTuple, tuple);
			
			p.savePage();
			System.out.println("Table Updated Successfully");
		}
		else{
			System.out.println("No rows were updated");
		}
		table.saveTable();
		
//		for(int i=0 ;i<pages.size();i++){
//			if((compareTo(pages.get(i).getPagemin(),ckValue)>0 && compareTo(pages.get(i).getPagemax(),ckValue)<0) || compareTo(pages.get(i).getPagemin(),obj)==0 || compareTo(pages.get(i).getPagemax(),obj)==0){
//				p=pages.get(i);
//				System.out.println("Page found");
//			}
//		}
//		
//		p.loadPage();
//		
//		Vector tuples=p.getTuplesinpage();
//		//Enumeration enu=htblColNameValue.keys();
//		Hashtable update;
//		for(int i=0 ;i<tuples.size();i++){
//			 update=(Hashtable) tuples.get(i);
//			 System.out.println("Searching for the correct tuple");
//			 System.out.println(ck);
//			 System.out.println(update.get(ck));
//			 
//			if(compareTo(update.get(ck),ckValue)==0){
//				
//				
//				System.out.println("Found it!!");
//				
//				for(int j=0;j<htblColNameValue.size();j++){
//					String s=(String) enu.nextElement();
//					update.replace(s,htblColNameValue.get(s));
//				}
//				System.out.println("updating tuple");
//				tuples.set(i, update);
//				break;
//				
//			}
//		}
//		
//		p.setTuplesinpage(tuples);
//		p.savePage();
//		table.saveTable();
	}
	
	
	public void deleteFromTable(String strTableName, Hashtable<String,Object> htblColNameValue) throws DBAppException{
		if(!exists(strTableName)){
			throw new DBAppException("This table doesn't exist");
		}
		
		System.out.println("fetching table...");
		Table table = getTable(strTableName);
		table = table.loadTable();
		
		if(htblColNameValue.size() == 0){	// no condition --> deletes all tuples from table
			System.out.println("deleting all from table " + strTableName);
			
			Vector<Page> pages = table.getPages();
			
			for(int i = pages.size()-1; i >= 0; i--){
				Page p = pages.get(i).loadPage();
				//p.loadPage();
				p.clearPage();
				//p.savePage();
				table.getPages().remove(i);
				p.deletePage();
			}
			
			for(int i = 0; i < table.getIndices().size(); i++){
				Octree index = table.getIndices().get(i);
				index = index.loadIndex();
				index.clearIndex();
				index.saveIndex();
			}
		}
		
		else{
			checkValueTypes(table, htblColNameValue);	//make sure conditions are consistent with table data types
			
			//boolean useIndex = false;
			
			if(htblColNameValue.size() == 3){
				System.out.println("checking for index...");
				//System.out.println(htblColNameValue);
				
				for(int i = 0; i < table.getIndices().size(); i++){
					Octree index = table.getIndices().get(i);
					index = index.loadIndex();
					
//					System.out.println(index.getCol1());
//					System.out.println(index.getCol2());
//					System.out.println(index.getCol3());
					
					//if all 3 cols are given in conditions
					if(htblColNameValue.containsKey(index.getCol1()) && htblColNameValue.containsKey(index.getCol2()) && htblColNameValue.containsKey(index.getCol3())){
						deleteWithIndex(index, htblColNameValue);
						//useIndex = true;
						index.saveIndex();
						table.saveTable();
						return;
					}
					index.saveIndex();
					//table.saveTable();
				}
			}
			
			//if(!useIndex){
				Hashtable<String, Vector> toBeDeleted = null;
				String ck = table.getClusterkey();
				//System.out.println(ck);
				
				//System.out.println(htblColNameValue);
				//System.out.println(htblColNameValue.containsKey(ck));
				
				if(htblColNameValue.containsKey(ck)){
					System.out.println("Binary Search... \n");
					Pair<Integer,Integer> indices = findTupleIndex(table, htblColNameValue.get(ck));
					
					if(indices != null && indices.getValue() >= 0){
						
						Page p = table.getPages().get(indices.getKey());
						p = p.loadPage();
						Hashtable tup = p.getTuplesinpage().get(indices.getValue());
						
						toBeDeleted = new Hashtable();
						Vector tupCK = new Vector();
						tupCK.add(tup.get(ck));
						toBeDeleted.put(p.getPageName(), tupCK);
						p.savePage();
					}
					else{
						//System.out.println("No rows were deleted");
						table.saveTable();
						return;
					}
				}
				else{
					System.out.println("Linear Search");
					toBeDeleted = findTuples(table, htblColNameValue);
				}
				
				System.out.println("deleting... " + toBeDeleted);
				deleteTuples(table, toBeDeleted);
			}
		//}
		table.saveTable();
		
	}
	
	public Iterator selectFromTable(SQLTerm[] arrSQLTerms, String[] strarrOperators) throws DBAppException{
		
		if(arrSQLTerms.length != strarrOperators.length + 1){
			throw new DBAppException("Invalid array sizes. Number of SQL Terms must be 1 more than the number of operators");
		}
		
				
		Table table = getTable(arrSQLTerms[0]._strTableName);	//assuming all queries are on same table since we dont support joins
		table = table.loadTable();
		
		Octree index = null;	//store index to search from (if any)
		Object[] values = new Object[3]; 	//hold values of cols to search in index (exact query)
		Point p = new Point();		//store values of exact query (if using index)

		
		Vector<String> colNames = new Vector<String>();
		
		for(int i = 0; i < arrSQLTerms.length; i++){
			if(!colNames.contains(arrSQLTerms[i]._strColumnName))
				colNames.add(arrSQLTerms[i]._strColumnName);
		}
		
		
		
		if(colNames.size() == 3){
			if(strarrOperators.length == 2){
				if (strarrOperators[0].equals("AND") && strarrOperators[1].equals("AND")){
			
					for(int i  = 0; i < table.getIndices().size(); i++){	//check that all 
										
						Octree in = table.getIndices().get(i);
						in = in.loadIndex();
						
						if(in.hasCol(colNames.get(0)) && in.hasCol(colNames.get(1)) && in.hasCol(colNames.get(2))){
							index = in;
							break;		//index on 3 cols found
						}
						else
							in.saveIndex();
					}
				}
			}
		}
		
	
		
		Vector res = new Vector();		//tuples to return
		
		Vector<Vector> queryRes = new Vector<Vector>();	//vector of vectors of tuples result from each query
		
		for(int i = 0; i< arrSQLTerms.length; i++){
			
			SQLTerm query = arrSQLTerms[i];
			
			String tableName = query._strTableName;
			String colName = query._strColumnName;
			String operator = query._strOperator;
			Object value = query._objValue;
			
			//if(tableName == "" || colName)
			
			checkForSelect(tableName, colName, value);
			checkArOp(operator);
			
			//Table table = getTable(tableName);	
			//table = table.loadTable();
			
			if(index != null){
				if(colName.equals(index.getCol1())){
					values[0] = value;
				}
				else if(colName.equals(index.getCol2())){
					values[1] = value;
				}
				else if(colName.equals(index.getCol3())){
					values[2] = value;
				}
				
			}
			
			if(index == null)
				queryRes.add(findTuplesOpr(table, colName, value, operator));
			
		}
		
		if(index != null){
			
			System.out.println("Selecting from index " + index.getName());
			p = new Point(values[0], values[1], values[2]);
			p.toLowerCase();
			
			Hashtable <String, Vector> pageTuples = index.searchExact(p);
			
			if(pageTuples != null){
			
				Enumeration e = pageTuples.keys();
			
				while(e.hasMoreElements()){
					String pageName = (String) e.nextElement();
					
					Vector cksInPage = pageTuples.get(pageName);
					//System.out.println(cksInPage);
					
					int pageIndex = table.getPageIndex(pageName);
					//System.out.println(pageIndex);
					
					Page page = table.getPages().get(pageIndex);
					page = page.loadPage();
					
					for(int j = 0; j < cksInPage.size(); j++){
						Object ck = cksInPage.get(j);
						//System.out.println(ck);
						
						int tupleIndex = binarySearch(page, ck);
						
					//	System.out.println(tupleIndex);
						
						res.add(page.getTuplesinpage().get(tupleIndex));
					}
					
					page.savePage();
					
				}
			}
			
		}
		
		else{
			
			if(queryRes.size() > 0){
				res = queryRes.get(0);
				
				for(int i = 0; i < strarrOperators.length; i++){
					
					checkLogOp(strarrOperators[i]);
					
					Vector query2 = queryRes.get(i+1);
					
					res = logicalOpr(res, query2, strarrOperators[i]);
				}
			}
		}
		
		table.saveTable();
		
		Iterator result = res.iterator();
		return result;
	}
	
	
	public void createIndex(String strTableName, String[] strarrColName) throws DBAppException{
		
		if(!exists(strTableName)){
			throw new DBAppException("This table doesn't exist");
		}
		
		 Table table = getTable(strTableName);
		 table = table.loadTable();
		
		if(strarrColName.length != 3){
			throw new DBAppException("An index can only be created on exactly 3 columns");
		}
		
		
		Vector file = DBApp.readFile("resources/metadata.csv");
		
		boolean indexCreated = true;
		
		 
		 Object minCol1 = null;
		 Object maxCol1 = null;
		 Object minCol2 = null;
		 Object maxCol2 = null;
		 Object minCol3 = null;
		 Object maxCol3 = null;
		 
		 
		 String indexName = strarrColName[0]+strarrColName[1]+strarrColName[2]+"Index";
		 
		 File temp = new File("resources/temp.csv");
		 File metadata = new File("resources/metadata.csv");

		 FileWriter fwriter;
			
			try {
				fwriter = new FileWriter(temp , true);
				PrintWriter writer = new PrintWriter(fwriter);
				
				 for (Object O : file) {	//loop over columns of table
					   
					String[] col =(String[]) O;	//get column (attribute)
					
					if(col[0].equals(strTableName)){
					
						String colName = col[1];		//get column name 
						String colType = col[2];
						
						
						if(colName.equals(strarrColName[0])){
							minCol1 = stringToObj(col[6], colType); 	//assign min of column
							maxCol1 = stringToObj(col[7], colType);	//assign max of column
							
							if(colName.equals(table.getClusterKey())){
								temp.delete();
								throw new DBAppException("Can't create index on primary key");
							}
							
							if(!col[4].equals("null")){
								temp.delete();
								throw new DBAppException("There is already an index for this column");
							}
						
							col[4] = indexName;
							col[5] = "Octree";
						}
						
						else if(colName.equals(strarrColName[1])){
							minCol2 = stringToObj(col[6], colType); 	//assign min of column
							maxCol2 = stringToObj(col[7], colType);	//assign max of column
							
							if(colName.equals(table.getClusterKey())){
								temp.delete();
								throw new DBAppException("Can't create index on primary key");
							}
							
							if(!col[4].equals("null")){
								temp.delete();
								throw new DBAppException("There is already an index for this column");
							}
							
							col[4] = indexName;
							col[5] = "Octree";
						}
						
						else if(colName.equals(strarrColName[2])){
							minCol3 = stringToObj(col[6], colType); 	//assign min of column
							maxCol3 = stringToObj(col[7], colType);	//assign max of column
							
							if(colName.equals(table.getClusterKey())){
								temp.delete();
								throw new DBAppException("Can't create index on primary key");
							}
							
							if(!col[4].equals("null")){
								temp.delete();
								throw new DBAppException("There is already an index for this column");
							}
							
							col[4] = indexName;
							col[5] = "Octree";
						}
					}
						
					writer.write(String.join(",", col));
					writer.print("\n");
				 }
				 
				 writer.close();
			
			} catch (IOException e) {
				temp.delete();
				throw new DBAppException(" Error occurred while writing in metadata file ");
				//e.printStackTrace();
			}
			
			 if(minCol1 == null || maxCol1 == null || minCol2 == null || maxCol2 == null || minCol3 == null || maxCol3 == null)
				 indexCreated = false;
				 
		 
			 if(!indexCreated){
				 temp.delete();
				 throw new DBAppException("One or more of the columns you entered does not exist");
			 }
			 
			
		
			 Point min = new Point(minCol1, minCol2, minCol3);
			 Point max = new Point(maxCol1, maxCol2, maxCol3);
			 Octree index = new Octree(table, min, max, strarrColName);
			 index.createOctree();
			 
			// table.getIndices().add(index);
			 index = index.loadIndex();
			 
			 for(Page p: table.getPages()){
				 p = p.loadPage();
				 
				 for(Hashtable t: p.getTuplesinpage()){
					 index.insert(p, t);
				 }
				 p.savePage();
			 }
			 
//			boolean deleted = metadata.delete();
//			System.out.println(deleted);
//			
			if (!metadata.delete())
			{
			    throw new DBAppException(
			        "Failed to delete the file because: " +
			        getReasonForFileDeletionFailureInPlainEnglish(metadata));
			}
			
			File rename = new File("resources/metadata.csv");
			boolean renamed  = temp.renameTo(rename);
			System.out.println(renamed);
			 
			index.saveIndex();
			table.saveTable();
		 
	}
	
	
	public String getReasonForFileDeletionFailureInPlainEnglish(File file) {
	    try {
	        if (!file.exists())
	            return "It doesn't exist in the first place.";
	        else if (file.isDirectory() && file.list().length > 0)
	            return "It's a directory and it's not empty.";
	        else
	            return "Somebody else has it open, we don't have write permissions, or somebody stole my disk.";
	    } catch (SecurityException e) {
	        return "We're sandboxed and don't have filesystem access.";
	    }
	}
	
	//////////////////////////////////////////////Extra Methods
	
	//public static void insertToIndex()
	
	
	public void searchWithIndex(Octree index, SQLTerm[] queries, String[] operators){
		
		
		
		
	}
	
	
	public void deleteWithIndex(Octree index, Hashtable<String, Object> conditions) throws DBAppException{
		
		System.out.println("deleting using index " + index.getName() + "...");
		
		Hashtable<String, Vector> toDelete = index.getTuples(conditions);		//deletes key from octree and returns all tuples with that key
		System.out.println(toDelete);
		
		//toDelete is a hashtable of each page with a vector corresponding to all tuples in that page with the key
		
		Table table = index.getTable();
		
		Enumeration pages = toDelete.keys();
		
		while(pages.hasMoreElements()){
			
			String pageName = (String)pages.nextElement();
			
			int pageIndex = table.getPageIndex(pageName);
			
			Page page = table.getPages().get(pageIndex);
			System.out.println(toDelete.get(page));
			
			Vector CKs = toDelete.get(pageName);
			
			page = page.loadPage();
			
			for(int i = 0; i < CKs.size(); i++){
				int tupleIndex = binarySearch(page, CKs.get(i));
				
				if(tupleIndex < 0){
					throw new DBAppException("Tuple Not Found");
				}
				
				Hashtable tuple = page.getTuplesinpage().get(tupleIndex);
				
				table.deleteFromIndices(page, tuple);
				
				page.getTuplesinpage().remove(tupleIndex);
			}
			
			if(page.isEmpty()){
				//int pageIndex = table.getPageIndex(page.getPageName());
				table.getPages().remove(pageIndex);
				page.deletePage();
			}
			else{
				page.updateMaxMin(table.getClusterKey());
				page.savePage();
			}
			
		}
		
	}
	
	
	public int binarySearch(Page p, Object ck)
	{
		
		Vector<Hashtable> tuples = p.getTuplesinpage();
		
		String ckName = p.getTable().getClusterkey();
		
		System.out.println(ck);
		
	    int l = 0, r = tuples.size() - 1;
	    while (l <= r) {
	        int m = l + (r - l) / 2;
	
	        System.out.println(tuples.get(m).get(ckName));
	        
	        // Check if x is present at mid
	        if (compareTo(tuples.get(m).get(ckName), ck) == 0)
	            return m;
	
	        // If x greater, ignore left half
	        if (compareTo(tuples.get(m).get(ckName), ck) < 0)
	            l = m + 1;
	
	        // If x is smaller, ignore right half
	        else
	            r = m - 1;
	    }
	
	    // if we reach here, then element was
	    // not present
	    return -1;
	}
	
	
	public static void checkArOp(String s) throws DBAppException{
		if(!(s.equals(">") || s.equals(">=") || s.equals("<=") || s.equals("<") || s.equals("=") || s.equals("!=")))
			throw new DBAppException("Invalid operator");
	}
	
	public static void checkLogOp(String s) throws DBAppException{
		if(!(s.equals("OR") || s.equals("AND") || s.equals("XOR")))
			throw new DBAppException("Invalid operator");
	}
	
	
	
	public static Vector logicalOpr(Vector query1, Vector query2, String operator){
		
		Vector res = new Vector();
		
		
		switch(operator){
		case "OR": 
			for(int i = 0; i< query1.size(); i++){
				if(!res.contains(query1.get(i))){
					res.add(query1.get(i));
				}
			}
			for(int i = 0; i< query2.size(); i++){
				if(!res.contains(query2.get(i))){
					res.add(query2.get(i));
				}
			}
			break;
		case "AND":
			for(int i = 0; i< query1.size(); i++){
				if(query2.contains(query1.get(i)))
					res.add(query1.get(i));
//				
//				Hashtable tuple1 = (Hashtable)query1.get(i);
//				for(int j = 0; j < query2.size(); j++){
//					Hashtable tuple2 = (Hashtable)query2.get(i);
//					if(tuple1.equals(tuple2))
//						res.add(tuple1);
//				}
			}
			break;
		case "XOR": 
			for(int i = 0; i< query1.size(); i++){
				if(!query2.contains(query1.get(i)))
					res.add(query1.get(i));	
			}
			for(int i = 0; i< query2.size(); i++){
				if(!query1.contains(query2.get(i)))
					res.add(query2.get(i));
			}
			break;
		}
		
		//res = removeDuplicateResults(res);
		return res;
	}
	
	
//	public static Vector removeDuplicateResults(Vector resultsVector) {
//
//	    for(int i=0;i<resultsVector.size();i++){        
//	        for(int j=0;j<resultsVector.size();j++){            
//	                if(i!=j){                                            
//	                    Object resultsVectorObject1 = resultsVector.elementAt(i);
//	                    Object resultsVectorObject2 = resultsVector.elementAt(j);
//	                    Object[] resultsObjectArray1 = (Object[]) resultsVectorObject1;
//	                    Object[] resultsObjectArray2 = (Object[]) resultsVectorObject2;
//	                    if(Arrays.equals(resultsObjectArray1, resultsObjectArray2))
//	                    {
//	                        resultsVector.removeElementAt(j);
//	                    }
//	                }
//	        }
//	    }
//	    return resultsVector;
//	} 
	
	
public static Vector findTuplesOpr(Table table, String colName, Object value, String operator) throws DBAppException{
		
		//Hashtable<String,Vector> toReturn = new Hashtable<String,Vector>();
		
		//table.display();
	
		Vector toReturn = new Vector();
//		System.out.println(table.getTablename());
//		System.out.println(table.getPages().size());
		
		for(int i = 0; i < table.getPages().size(); i++){
			//System.out.println("test");
			Page page = table.getPages().get(i);
			page = page.loadPage();
			
			//System.out.println(page.getTuplesinpage());
			
			//Vector<Hashtable> tuplesToDelete = new Vector<Hashtable>();
			//Vector tuplesToReturn = new Vector();

			
			for(int j = 0; j < page.getTuplesinpage().size(); j++){
				Hashtable tuple = page.getTuplesinpage().get(j);
				
				Object tValue = tuple.get(colName);
				//System.out.println(colName);
				//System.out.println(tValue);
				
				if(!(tValue instanceof NULL) && compareOp(tValue, value, operator)){
					toReturn.add(tuple);
				}
			}
				
				//Enumeration conds = conditions.keys();
				
//				while(conds.hasMoreElements()){
//					String key = (String)conds.nextElement();
//					
//					if(tuple.get(key) instanceof NULL)	//if condition attribute in tuple is null --> not to be deleted
//						break;
//					
//					//if last condition is true
//					if(!conds.hasMoreElements() && (compareTo(tuple.get(key), conditions.get(key)) == 0)){
//						//System.out.println("tuple " + tuple.get(table.getClusterkey()) + " matches");
//						tuplesToDelete.add(tuple.get(ck));
//					}
//					
//					else if(compareTo(tuple.get(key), conditions.get(key)) != 0){
//						break;
//					}
//					
//				}
		
			
//			if(tuplesToReturn.size() > 0)
//				toReturn.put(page.getPageName(), tuplesToReturn);
//			
			page.savePage();
		}
		System.out.println(toReturn);
		return toReturn;
	}


	public static boolean compareOp(Object value1, Object value2, String operator) throws DBAppException{
		//System.out.println(operator);
		
		switch(operator){
			case ">": return (compareTo(value1, value2) > 0);
			case "<": return (compareTo(value1, value2) < 0);
			case "=": return (compareTo(value1, value2) == 0);
			case "!=": 
				if (value1 instanceof Date) 
					return !(((Date)value1).equals((Date)value2));
				else
					return !(((String)value1).equals((String)value2));
			case ">=": return ((compareTo(value1, value2) > 0) || (compareTo(value1, value2) == 0)) ;
			case "<=": return ((compareTo(value1, value2) < 0) || (compareTo(value1, value2) == 0)) ;
			default: throw new DBAppException("Invalid Operator");
		}
	}
	
	
	public static boolean check4Types(String s){
		String integer =  "java.lang.Integer";
		String str = "java.lang.String";
		String dbl = "java.lang.Double";
		String date = "java.util.Date";
		if(s.equals(integer) || s.equals(str) || s.equals(dbl) || s.equals(date))
			return true;
		else
			return false;
	}
	
	
	public static void checkForSelect(String tableName, String colName, Object value) throws DBAppException{
		
		Vector file = readFile("resources/metadata.csv");
		 
		//String tableName = table.getTablename();
		
		boolean colFound = false;
		boolean tableFound = false;
		
		for (Object O : file) {	//loop over columns of table
			   
			String[] col =(String[]) O;	//get column (attribute)
			
			if(col[0].equals(tableName)){
				
				tableFound = true;
			
				String columnName = col[1];		//get column name 
				
				if(columnName.equals(colName)){
					colFound = true;
					
				//check data type				
					String colType = col[2];		//get column data type
			
					if(!(checkDataType(value, colType))){
						throw new DBAppException("Incompatible data types");			
					}
					
				//check range	
					String colmin = col[6];
					String colmax = col[7];
					
					Object colMin = stringToObj(colmin, colType);
					Object colMax = stringToObj(colmax, colType);
						
					if((compareTo(value, colMin) < 0) || (compareTo(value, colMax) > 0))
						throw new DBAppException("Input not in range");
					
				}
			}
			else{
				if(tableFound)
					break;
			}
		}
		
		if(!tableFound){
			throw new DBAppException("Invalid Table Name");
		}
		
		if(!colFound){
			throw new DBAppException("Invalid Column Name");
		}
		
	}
	
	
	public static void checkForUpdate(Table table, Hashtable attributeValue) throws DBAppException{
		
		 Vector file = readFile("resources/metadata.csv");
		 
		 String tableName = table.getTablename();
		 Hashtable<String,Object> conds = (Hashtable) attributeValue.clone();

			
		   for (Object O : file) {	//loop over columns of table
			   
				String[] col =(String[]) O;	//get column (attribute)
				
				if(col[0].equals(tableName)){
				
					String colName = col[1];		//get column name 
					String colType = col[2];		//get column data type
					
//					if(colName.equals(table.getClusterkey())){
//						Object ck = stringToObj(ckValue, colType);
//						
//					}
					
					if(attributeValue.containsKey(colName)){
						
						Object value = attributeValue.get(colName);	//value to be inserted for column
						
						
					//check duplicates if primary key	
						if(colName.equals(table.getClusterkey())){
							throw new DBAppException("Cannot update primary key!");
						
//							 if(ckExists(table, value))
//								 throw new DBAppException("The primary key cannot contain duplicates");
//							 System.out.println("no ck duplicates! \n");
						 
						}
						
					//check data type				
						//String colType = col[2];		//get column data type
				
						if(!(checkDataType(value, colType))){
							throw new DBAppException("Incompatible data types");			
						}
						
					//check range	
						String colmin = col[6];
						String colmax = col[7];
						
						Object colMin = stringToObj(colmin, colType);
						Object colMax = stringToObj(colmax, colType);
							
						if((compareTo(value, colMin) < 0) || (compareTo(value, colMax) > 0))
							throw new DBAppException("Input not in range");
						
					}
						
					conds.remove(colName);	
				}
			}
		
		   if(!conds.isEmpty())		//no more input fields
			   throw new DBAppException("There are incorrect columns that doesn't exist in the table");
	}
	
	
	//returns page index, tuple index of tuple with ck
	public Pair<Integer,Integer> findTupleIndex(Table table, Object ckValue) throws DBAppException{
		
		
		System.out.println("finding indices...");
		
		Vector<Page> pages = table.getPages();
		
		String ckName = table.getClusterkey();
		
		int pageIndex;
		int tupleIndex;
		
		
		for(int i = 0; i < pages.size(); i++){
			
			Page currP = pages.get(i).loadPage();
				
			
			if(compareTo(ckValue, currP.getPagemax()) <= 0){	//value in page range
				
				if(compareTo(ckValue, currP.getPagemin()) >= 0){
				
					System.out.println("Tuple should be in " + currP.getPageName()+"\n");
					
					tupleIndex = binarySearch(currP, ckValue);
					
//					Vector tuples = currP.getTuplesinpage();
//					Vector CKs = new Vector();
//					
//					for(int j = 0; j < tuples.size(); j++){
//						Hashtable tup = (Hashtable) tuples.get(j);
//						CKs.add(tup.get(ckName));
//					}
						
					pageIndex = i;
					//tupleIndex = Collections.binarySearch(CKs, ckValue);
					currP.savePage();
					
					//System.out.println("Page " + pageIndex + " " + tupleIndex);
					
					
					return new Pair(pageIndex, tupleIndex);
				}
				else{
					currP.savePage();
					return null;
				}
			}
//			if(currP.equals(pages.lastElement())){
//				currP.savePage();
//				throw new DBAppException("Tuple Not Found!");
//
//			}
			currP.savePage();
		}	
		return null;
	}

	
	
	public void deleteTuples(Table table, Hashtable<String, Vector> toDelete) throws DBAppException{
		
		String ck = table.getClusterkey();
		
		for(int i = table.getPages().size()-1; i >= 0; i--){
			
			Page page = table.getPages().get(i);
			String pageName = "Page " + (i+1);
			//System.out.println(page);
			
			if(toDelete.containsKey(pageName)){
				page = page.loadPage();
				Vector toDeleteInPage = toDelete.get(pageName);
				
				for(int j = 0; j < toDeleteInPage.size(); j++){
					
					int tupleIndex = binarySearch(page, toDeleteInPage.get(j));
					
					Hashtable tuple = page.getTuplesinpage().get(tupleIndex);
					
					
					System.out.println("Deleting tuple..." + page.getTuplesinpage().get(tupleIndex));
					
//					for(int k = 0; k < table.getIndices().size(); k++){
//						Octree index = table.getIndices().get(k);
//						index = index.loadIndex();
//						
//						index.deleteTuple(page, tuple);
//						
//						index.saveIndex();
//					
//						
////						String col1 = index.getCol1();
////						String col2 = index.getCol2();
////						String col3 = index.getCol3();
////						
////						Hashtable conditions = new Hashtable();
////						
////						conditions.put(col1, tuple.get(col1));
//						
//					}
					table.deleteFromIndices(page, tuple);
					
					page.getTuplesinpage().remove(tupleIndex);
				}
				
//				for(int j = page.getTuplesinpage().size()-1; j >= 0; j--){
//					
//					Hashtable tuple = page.getTuplesinpage().get(j);
//					
////					System.out.println(toDeleteInPage);
////					System.out.println(tuple);
//					
//					//if(containsCK(toDeleteInPage, ck, tuple.get(ck))){
//					if(toDeleteInPage.contains(tuple.get(ck))){
//						System.out.println("Deleting tuple..." + tuple);
//						//delete tuple from page
//						page.getTuplesinpage().remove(j);
//						
//					}
//				}
				
				if(page.isEmpty()){
					table.getPages().remove(i);
					page.deletePage();
				}
				else{
					page.updateMaxMin(ck);
					page.savePage();
				}
			}
		}
	}
	
	
//	public static boolean containsCK(Vector<Hashtable> tuples, String ckName, Object ck){
//		for(int i = 0; i<tuples.size(); i++){
//			Hashtable tuple = tuples.get(i);
//			if(compareTo(ck, tuple.get(ckName)) == 0)
//				return true;
//		}
//		return false;
//	}
	
	
	public static Hashtable<String,Vector> findTuples(Table table, Hashtable<String, Object> conditions){
		
		String ck = table.getClusterkey();
		
		Hashtable<String,Vector> toDelete = new Hashtable<String,Vector>();
		
		for(int i = 0; i < table.getPages().size(); i++){
			Page page = table.getPages().get(i);
			page = page.loadPage();
			
			//Vector<Hashtable> tuplesToDelete = new Vector<Hashtable>();
			Vector tuplesToDelete = new Vector();

			
			for(int j = 0; j < page.getTuplesinpage().size(); j++){
				Hashtable tuple = page.getTuplesinpage().get(j);
				
				Enumeration conds = conditions.keys();
				
				while(conds.hasMoreElements()){
					String key = (String)conds.nextElement();
					
					if(tuple.get(key) instanceof NULL)	//if condition attribute in tuple is null --> not to be deleted
						break;
					
					//if last condition is true
					if(!conds.hasMoreElements() && (compareTo(tuple.get(key), conditions.get(key)) == 0)){
						//System.out.println("tuple " + tuple.get(table.getClusterkey()) + " matches");
						tuplesToDelete.add(tuple.get(ck));
					}
					
					else if(compareTo(tuple.get(key), conditions.get(key)) != 0){
						break;
					}
					
				}
			}
			
			if(tuplesToDelete.size() > 0)
				toDelete.put(page.getPageName(), tuplesToDelete);
			
			page.savePage();
		}
		System.out.println(toDelete);
		return toDelete;
		
	}
	
	public static void checkValueTypes(Table table, Hashtable<String, Object> conditions) throws DBAppException{
		
		 Vector file = readFile("resources/metadata.csv");
		 
		 String tableName = table.getTablename();
		 Hashtable<String,Object> conds = (Hashtable) conditions.clone();
		 
		 //Enumeration e = conditions.keys();
			
		   for (Object O : file) {	//loop over columns of table
			   
				String[] col =(String[]) O;	//get column (attribute)
				//System.out.println(col);
				
				if(col[0].equals(tableName)){
				
					String colName = col[1];		//get column name 
					
					if(conds.containsKey(colName)){
						Object value = conds.get(colName);					//value to be inserted for column
						String colType = col[2];		//get column data type
						
						if(!(checkDataType(value, colType))){
							throw new DBAppException("Incompatible data types");			
						}
						
						
						conds.remove(colName);	
					}
				}
		   }
		   
		   if(!conds.isEmpty())		//no more input fields
			   throw new DBAppException("There are incorrect columns that don't exist in the table");
		
	}
	
	
	
	
	public static int compareTo(Object o1, Object o2){
		
		//Class type = o1.getClass();
		//System.out.println(o1.getClass() + "      " + o2.getClass());
		
		if(o1 instanceof String && o2 instanceof String){
			return ((String)o1).toLowerCase().compareTo(((String)o2).toLowerCase());
		}
		
		else if(o1 instanceof Date && o2 instanceof Date){
			return ((Date)o1).compareTo((Date)o2);
		}
		else if(o1 instanceof Integer && o2 instanceof Integer){
			return ((Integer)o1) - ((Integer)o2);
		}
		else {
			return ((Double)o1).compareTo((Double)o2);
		}
		
	}
	
	public static boolean ckExists(Table table, Object ck){
		System.out.println("checking for pk duplicate...");
		Vector<Page> pages = table.getPages();
		String ckName = table.getClusterkey();
		
		for(int i = 0; i < pages.size(); i++){
			//Page p = pages.get(i);
			Page p = pages.get(i).loadPage();
						
			if(compareTo(ck, p.getPagemax()) <= 0){
				if(compareTo(ck, p.getPagemin()) >= 0){
					for(int j = 0; j < p.getTuplesinpage().size(); j++){
						Hashtable t = (Hashtable) p.getTuplesinpage().get(j);
						if(t.get(ckName).equals(ck)){
							p.savePage();
							//p = null;
							return true;
						}
					}
					p.savePage();
//					p = null;
//					System.gc();
					return false;
				}
				else{
					p.savePage();
					return false;
				}
			}
			p.savePage();
		}
		return false;
	}
	
	
	
	public static Page findPagetoInsert(Table table, Hashtable<String,Object> tuple){
		
		System.out.println("finding page...");
		
		Vector<Page> pages = table.getPages();
		//System.out.println(tuple);
		
		String ckName = table.getClusterkey();
		Object ckValue = tuple.get(ckName);
		
		//System.out.println(pages);
		
		
		if(pages.size() == 0){
			//System.out.println("test2");
			Page p = new Page(table);
			//table.getPages().add(p);
			p.createPage();
			p = p.loadPage();
			return p;
		}
		
		//System.out.println(ckValue);
		
		for(int i = 0; i < pages.size(); i++){
			
			Page currP = pages.get(i).loadPage();
			//currP.loadPage();
			
			//System.out.println(getPageIndex(currP));
			
			
			if(i == pages.size() - 1){		//last page
				//System.out.println(ckValue);
				//System.out.println(currP.getPagemax());
				
				if(compareTo(ckValue, currP.getPagemax()) > 0 && currP.isFull()){		//last page is full
					//System.out.println("test");
					Page p = new Page(table);		//create new page
					//table.getPages().add(p);
					p.createPage();	//create page ser file
					p = p.loadPage();	//access page
					currP.savePage(); 	//no longer need currP
					return p;
				}
				else
					return currP;
			}
			
			else{
				
				//System.out.println("test");
				//System.out.println(getPageIndex(nextP));
				
				//System.out.println(currP.getPagemax());
				
				if(compareTo(ckValue, currP.getPagemax()) < 0){	//value in page range
					return currP;
				}
				
				else {		//greater than page max
					Page nextP = pages.get(i+1).loadPage();
					//nextP.loadPage();
					if(compareTo(ckValue, nextP.getPagemin()) < 0){	//less than next page min (in between pages)
						if(!currP.isFull())	{	//if first page not full --> insert in it
							nextP.savePage();	//no longer need next page
							return currP;		//return first page
						}
						else{
							currP.savePage(); 	//no longer need curr page
							return nextP;		
						}
					}
					nextP.savePage();
				}
				currP.savePage();
			}	
		}
		
		return null;
	}
	
	
	public static void insertInPage(Page page, Hashtable<String, Object> tuple){
		
		System.out.println("inserting...");
		
		Table table = page.getTable();	//get table that page represents
		String CK = table.getClusterkey();		//get table clustering key
		
		if(page.isEmpty()){
					//add tuple to vector in page
			page.setPagemax(tuple.get(CK));
			page.setPagemin(tuple.get(CK));
			page.getTuplesinpage().add(tuple);
			sortVector(page.getTuplesinpage(), CK);	//sort tuples in page based on clustering key

		}
		
		else{
			page.getTuplesinpage().add(tuple);
			sortVector(page.getTuplesinpage(), CK);	//sort tuples in page based in clustering key
			page.updateMaxMin(CK);
//			if(compareTo(tuple.get(CK), page.getPagemin()) < 0){
//				page.setPagemin(tuple.get(CK));
//			}
//			
//			if(compareTo(tuple.get(CK), page.getPagemax()) > 0){
//				page.setPagemax(tuple.get(CK));
//			}
		}

		page.savePage();
		//page.getTuplesinpage().sort(CK);
	}
	
	public static void shiftTuples(Table table, Page page, Hashtable<String,Object> tuple) throws DBAppException{		
		
		//Table t = page.getTable().loadTable();
		
		if(!page.isFull()){
			//System.out.println(t.getPages());
			insertInPage(page, tuple);
			table.updateIndices(page, tuple);
			//page.savePage();
			return;
		}
		
		else{
			System.out.println("shifting..." + page.getPageName());
			//page.getTablename();
			//Table t = page.getTable();
			Vector<Page> pages = table.getPages();
			//System.out.println(table.getPages());
			
//			System.out.println("----------before shift "+  pageIndex + "---------");
//			t.display();
//			System.out.println("------------------------------------");
			
			int pageIndex = getPageIndex(page);
			
			Vector<Hashtable> v = page.getTuplesinpage();
			Hashtable<String,Object> toShift = v.remove(v.size()-1);	//remove last tuple in page
			
			//System.out.println("removed " + toShift);
			
			if(pageIndex == pages.size()-1){	//last page
			//if(page.equals(pages.lastElement())){
				Page p = new Page(table);
				//table.getPages().add(p);
				p.createPage();	//create ser file
				//p.loadPage();	//access page 
			}
			
			//System.out.println(pages);
			//System.out.println(pageIndex);
			Page nextPage = pages.get(pageIndex + 1).loadPage();
			//nextPage.loadPage();
			
			shiftTuples(table, nextPage, toShift);	//shift next tuples
			
			insertInPage(page, tuple);	//insert shifted tuple in page
			table.updateIndices(page, tuple);

			//page.savePage();
			
			//table.saveTable();
//			
//			System.out.println("----------after shift "+  pageIndex + "---------");
//			t.display();
//			System.out.println("------------------------------------");
		}
	}
	
	
	
	
	
	@SuppressWarnings("unchecked")
	public static void sortVector(Vector v, Comparable clusterKey){
		Collections.sort(v, new Comparator<Hashtable<String, Object>>() {
	   	@Override
			public int compare(Hashtable<String, Object> h1, Hashtable<String, Object> h2) {
				return compareTo(h1.get(clusterKey), h2.get(clusterKey));
			}            
	    });
	}

	
	public static Table getTable(String tableName){
		for(int i = 0; i < tables.size(); i++){
			if(tables.elementAt(i).getTablename().toLowerCase().equals(tableName.toLowerCase())){
				return tables.elementAt(i);
			}
		}
		return null;
	}

	
	
	//////////////////////////////////////////////////////////////////////////////////

	public static boolean checkDataType(Object data, String dataType){
		
		
		try {
			//System.out.println(data);
			//System.out.println(data.getClass().getName());
			
			//System.out.println(dataType);
			Class type = Class.forName(dataType);
			//System.out.println(type);
			//return true;
			
			//System.out.println(data.getClass().equals(type));
			
			return data.getClass().equals(type);
			
		}catch(ClassNotFoundException e){
			e.printStackTrace();
		}
		
		return false;
	}
	
	
	public static Date checkDate(String data)throws DBAppException{
	   	 
		 try{
	    	 String pattern = "yyyy-MM-dd";
	    	 SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
	    	 Date d= simpleDateFormat.parse(data);
	    	 return d;
	    	 
			} catch (ParseException e) {
				throw new DBAppException("wrong format");
			}
	    	
	}
	
	public static Hashtable createTuple(Table table, Hashtable<String,Object> tupleInputs) throws DBAppException {
		
		 String tableName = table.getTablename();
		 String clusterKey = table.getClusterkey();
		 Hashtable update = (Hashtable) tupleInputs.clone();
		 Hashtable resTuple = new Hashtable();
		 
		 //System.out.println(tupleInputs);
		 
		 if(!tupleInputs.containsKey(clusterKey) || tupleInputs.get(clusterKey) == null)	//make sure cluster key != null
			    throw new DBAppException("Primary Key Cannot be Null!");	
		 
//		 for(int i = 0; i < table.getPages().size(); i++){
//			 Page page = table.getPages().get(i);
//			 for(int j = 0; j < page.getTuplesinpage().size(); j++){
//				 if(((Hashtable)page.getTuplesinpage().get(i)).get(clusterKey).equals(tupleInputs.get(clusterKey))){
//					 
//				 }
//			 }
//		 }
		 
		 //int i = 0;
//		 Object ck;
//		 if(tupleInputs.get(clusterKey) instanceof Date){
//			 ck = checkDate((String)tupleInputs.get(clusterKey));		//check date format
//		 }
//		 else{
//			 ck = tupleInputs.get(clusterKey);
//		 }
		 
		 Object ck = tupleInputs.get(clusterKey);
		 //System.out.println(ck);
		 
		 if(table.getPages().size() > 0){
			 if(ckExists(table, ck))
				 throw new DBAppException("The primary key cannot contain duplicates");
			 System.out.println("no ck duplicates! \n");
		 }
		
		 
//		 if(table.getPages().size() > 0){
//			 
////			 Page page = findPagetoInsert(table, tupleInputs);
////			// System.out.println(page.getTuplesinpage());
////			 for(int j = 0; j < page.getTuplesinpage().size(); j++){
////					if(((Hashtable)page.getTuplesinpage().get(j)).get(clusterKey).equals(tupleInputs.get(clusterKey)))
////						throw new DBAppException("The primary key cannot contain duplicates");
////				}
//		 }
		 
		 
		 
		 
//		 while(i < table.getPages().size()){
//			Page page = table.getPages().get(i);
//			System.out.println(ck);
//			System.out.println(page.getPagemax());
//			if(compareTo(ck, page.getPagemax()) > 0){
//				i++;
//			}
//			else{
//				if(compareTo(ck, page.getPagemin()) >= 0){
//					for(int j = 0; j < page.getTuplesinpage().size(); j++){
//						if(((Hashtable)page.getTuplesinpage().get(i)).get(clusterKey).equals(tupleInputs.get(clusterKey)))
//							throw new DBAppException("The primary key cannot contain duplicates");
//					}
//				}
//			}
//		}
		 
		 Vector file = readFile("resources/metadata.csv");
		 
		 
	
		   for (Object O : file) {	//loop over columns of table
			   
				String[] col =(String[]) O;	//get column (attribute)
				//System.out.println(col);
				
				if(col[0].equals(tableName)){	
					String colName = col[1];		//get column name 
					String colType = col[2];		//get column data type
					
					Object value;					//value to be inserted for column
				
					//System.out.println(colName);
					
					if(!tupleInputs.containsKey(colName)){
						//System.out.println("test");
						//value = new NULL();	
						throw new DBAppException(colName +" cannot be null");
						//if attribute has no input value -> null
					}
							//set value of col in hashtable to null
							
					
					else {
						value = tupleInputs.get(colName);	//get input value of attribute 
						update.remove(colName);	
						
//						System.out.println(value);
//						System.out.println(colType);

						if(!(checkDataType(value, colType))){
							throw new DBAppException("Incompatible data types");			

						}
						
						//String datatypeofcol = col[2];
						String colmin = col[6];
						String colmax = col[7];
						
						Object colMin = stringToObj(colmin, colType);
						Object colMax = stringToObj(colmax, colType);
				
								
						
						
						//column could have string min and max -> compare to not <=
						
//						System.out.println(value.getClass());
//						
						if(!(value instanceof NULL)){
							
							//System.out.println(value);
							//System.out.println(colMin);
							//System.out.println(colMax);
							
							if((compareTo(value, colMin) < 0) || (compareTo(value, colMax) > 0))
								throw new DBAppException("Input not in range");
						}
					}
				
					
					
				
//					if(!(Integer.parseInt(colMin)<=Integer.parseInt((String)tupleInputs.get(colName)) && Integer.parseInt((String)maxofcol)>=Integer.parseInt((String) tupleinputs.get(colname)))){
//					
//							throw new DBAppException("Input not in range");	
//							
//					}
				
					resTuple.put(colName,value);	//insert value in tuple to be returned
					//System.out.println(resTuple);
				
				 }
				
			 }
		   
		   if(update.isEmpty())		//no more input fields
		       return resTuple;		
		   
		   else 					//remaining input fields that are not in table
			   throw new DBAppException("There are incorrect columns that doesn't exist in the table");
				 
	}
			  
	
	public static Object stringToObj(String s, String colType){
		if(colType.equals("java.lang.Integer"))
			return Integer.parseInt(s);
		
		else if (colType.equals("java.util.Date")){
			try {
				return checkDate(s);
			} catch (DBAppException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		else if (colType.equals("java.lang.Double"))
			return Double.parseDouble(s);
		
		return s;
	}
	
	//to check if the table name exists
	
//	public static boolean exists(String tablename)
//	{
//		System.out.println("checking if table exists...");
//		
//		for(int i = 0; i < tables.size(); i++){
//			tables.get(i).loadTable();;
//			//System.out.println(tables.get(i).getTablename());
//			if(tables.get(i).getTablename().equals(tablename)){
//				tables.get(i).saveTable();
//				return true;
//			}
//			tables.get(i).saveTable();
//		}
//		
//		return false;
//	}
	
	public boolean exists(String strTableName) throws DBAppException{
		try {
			File file = new File("resources/metadata.csv");
			if(file.exists()){
				Vector meta = readFile("resources/metadata.csv");
				for (Object O : meta) {
					String[] curr = (String[]) O;
					if (curr[0].toLowerCase().equals(strTableName.toLowerCase())) {
						return true;
					}
				}
				return false;
			}
			return false;
		}
		catch (Exception e) {
			return false;
		}
	
	}
	
	//to read files

	public static Vector readFile(String path) throws DBAppException {
		try {
     		////////////////////////////////////////////////////////////////////////////////////////////////System.out.println("IO||||\t readFile :"+path);
			String currLine = "";
			FileReader fileReader = new FileReader(path);
			BufferedReader br = new BufferedReader(fileReader);
			Vector metadatafile = new Vector();
			while ((currLine = br.readLine()) != null) {
				metadatafile.add(currLine.split(","));
			}
			fileReader.close();
			return metadatafile;
		}
		catch(IOException e) {
			e.printStackTrace();
			throw new DBAppException("IO Exception while reading file\t"+path);
		}
	}
	
	
	
	
//	public static void writeFile(String path){
//		
//		try {
//			
//			CSVWriter writer = new CSVWriter(new FileWriter(path), ',');
//			writer.writeAll(csvBody);
//			writer.flush();
//			writer.close();
//			
//			String currLine = "";
//			FileReader fileReader = new FileReader(path);
//			BufferedReader br = new BufferedReader(fileReader);
//			Vector metadatafile = new Vector();
//			while ((currLine = br.readLine()) != null) {
//				metadatafile.add(currLine.split(","));
//			}
//			return metadatafile;
//		}
//		catch(IOException e) {
//			e.printStackTrace();
//			throw new DBAppException("IO Exception while reading file\t"+path);
//		}
//		
//		
//	}
//	
	
	public static int getPageIndex(Page p) throws DBAppException{
		
		Table t = p.getTable();
		for(int i = 0; i < t.getPages().size(); i++){
			if(p.equals(t.getPages().get(i))){
				return i;
			}
		}
		
		throw new DBAppException("Page not Found");
	}

	
	
	
	public void testCreate() throws DBAppException{
		Hashtable<String,String> types = new Hashtable<String,String>();
		types.put("ID", "java.lang.Integer");
		types.put("Name", "java.lang.String");
		types.put("GPA", "java.lang.Double");
		types.put("Age", "java.lang.Integer");
		types.put("DoB", "java.util.Date");

		
		Hashtable<String, String> mins = new Hashtable<String, String>();
		mins.put("ID", "1");
		mins.put("Name", "a");
		mins.put("GPA", "0.7");
		mins.put("Age", "2");
		mins.put("DoB", "2010-01-01");
		
		Hashtable<String, String> maxs = new Hashtable<String, String>();
		maxs.put("ID", "100");
		maxs.put("Name", "ZZZZZZ");
		maxs.put("GPA", "5.0");
		maxs.put("Age", "50");
		maxs.put("DoB", "2011-01-01");

		
		//DBApp db = new DBApp();
		
		createTable("Student", "ID", types, mins, maxs);
	}
	
	
	public void testInsert() throws DBAppException{
	
		Table table = getTable("Student");		//get table 3shan a3raf a call table.display();

		//---------------------------------------------------------------------------------------

		Hashtable h1 = new Hashtable();
		h1.put("ID", 1);
		h1.put("GPA", 1.1);
		
		Hashtable h2 = new Hashtable();
		h2.put("Name", "Malak");
		h2.put("ID", 2);
		
		Hashtable h3 = new Hashtable();
		h3.put("Name", "Ahmed");
		h3.put("ID", 3);
		h3.put("GPA", 2.0);
		
		Hashtable h4 = new Hashtable();
		h4.put("ID", 4);
		h4.put("GPA", 2.2);
		
		Hashtable h6 = new Hashtable();
		h6.put("ID", 6);
		h6.put("Name", "Sara");
		h6.put("GPA", 2.2);
		
		Hashtable h7 = new Hashtable();
		h7.put("ID", 7);
		h7.put("GPA", 3.4);
		
		Hashtable h8 = new Hashtable();
		h8.put("ID", 8);
		h8.put("Name", "Omar");
		//h8.put("GPA", 3.6);
		
		Hashtable h9 = new Hashtable();
		h9.put("ID", 9);
		h9.put("GPA", 3.8);
		h9.put("Name", "Youssef");
		
		Hashtable h10 = new Hashtable();
		h10.put("ID", 10);
		h10.put("GPA", 4.0);
		
		Hashtable h11 = new Hashtable();
		h11.put("ID", 11);
		h11.put("Name", "Ahmed");
		h11.put("GPA", 4.2);
		
		Hashtable h12 = new Hashtable();
		h12.put("ID", 12);
		h12.put("Name", "Malak");
		h12.put("GPA", 4.3);
		
		//---------------------------------------------------------------------------------------
		
		System.out.println("inserting 1");
		insertIntoTable("Student", h1);
		//table = table.loadTable();
		table.display();
		//table.saveTable();
		System.out.println("------------------------------------------------------------------------------------------------------");
		System.out.println("------------------------------------------------------------------------------------------------------");

		
		System.out.println("inserting 2...");
		insertIntoTable("Student", h2);
		//table = table.loadTable();
		table.display();
		//table.saveTable();
		System.out.println("------------------------------------------------------------------------------------------------------");
		System.out.println("------------------------------------------------------------------------------------------------------");

		
		System.out.println("inserting 4...");
		insertIntoTable("Student", h4);
		table.display();
		System.out.println("------------------------------------------------------------------------------------------------------");
		System.out.println("------------------------------------------------------------------------------------------------------");

		
		System.out.println("inserting 3...");
		insertIntoTable("Student", h3);
		table.display();
		System.out.println("------------------------------------------------------------------------------------------------------");
		System.out.println("------------------------------------------------------------------------------------------------------");

		
		System.out.println("inserting 6...");
		insertIntoTable("Student", h6);
		table.display();
		System.out.println("------------------------------------------------------------------------------------------------------");
		System.out.println("------------------------------------------------------------------------------------------------------");

		
		System.out.println("inserting 7...");
		insertIntoTable("Student", h7);
		table.display();
		System.out.println("------------------------------------------------------------------------------------------------------");
		System.out.println("------------------------------------------------------------------------------------------------------");

		
		System.out.println("inserting 8...");
		insertIntoTable("Student", h8);
		table.display();
		System.out.println("------------------------------------------------------------------------------------------------------");
		System.out.println("------------------------------------------------------------------------------------------------------");

		
		System.out.println("inserting 9...");
		insertIntoTable("Student", h9);
		table.display();
		System.out.println("------------------------------------------------------------------------------------------------------");
		System.out.println("------------------------------------------------------------------------------------------------------");

		
		System.out.println("inserting 12...");
		insertIntoTable("Student", h12);
		table.display();
		System.out.println("------------------------------------------------------------------------------------------------------");
		System.out.println("------------------------------------------------------------------------------------------------------");

		
		
		Hashtable h5 = new Hashtable();
		h5.put("ID", 5);
		h5.put("GPA", 2.2);
		
		System.out.println("inserting 5...");
		insertIntoTable("Student", h5);
		table.display();
		System.out.println("------------------------------------------------------------------------------------------------------");
		System.out.println("------------------------------------------------------------------------------------------------------");

		
		System.out.println("inserting 10");
		insertIntoTable("Student", h10);
		table.display();
		System.out.println("------------------------------------------------------------------------------------------------------");
		System.out.println("------------------------------------------------------------------------------------------------------");

		
		System.out.println("inserting 11");
		insertIntoTable("Student", h11);
		table.display();
		System.out.println("------------------------------------------------------------------------------------------------------");
		System.out.println("------------------------------------------------------------------------------------------------------");

		
		Hashtable h16 = new Hashtable();
		h16.put("ID", 16);
		h16.put("Name", "Mariam");
		h16.put("GPA", 4.9);
		
		System.out.println("inserting 16");
		insertIntoTable("Student", h16);
		table.display();
		System.out.println("------------------------------------------------------------------------------------------------------");
		System.out.println("------------------------------------------------------------------------------------------------------");

		
		Hashtable h13 = new Hashtable();
		h13.put("ID", 13);
		h13.put("Name", "Zeina");
		//h13.put("GPA", 4.7);
		
		System.out.println("inserting 13");
		insertIntoTable("Student", h13);
		table.display();
		System.out.println("------------------------------------------------------------------------------------------------------");
		//System.out.println("------------------------------------------------------------------------------------------------------");

	}
	
	
	public void testInsert2() throws DBAppException{
		Table table = getTable("Student");		//get table 3shan a3raf a call table.display();

		//---------------------------------------------------------------------------------------

		Hashtable h1 = new Hashtable();
		h1.put("ID", 1);
		h1.put("Name", "Ahmed");
		h1.put("GPA", 1.1);
		h1.put("Age", 10);
		h1.put("DoB", checkDate("2010-02-04"));
		
		Hashtable h2 = new Hashtable();
		h2.put("Name", "Malak");
		h2.put("GPA", 2.3);
		h2.put("Age", 11);
		h2.put("ID", 2);
		h2.put("DoB", checkDate("2010-03-24"));

		
		Hashtable h3 = new Hashtable();
		h3.put("Name", "Omar");
		h3.put("ID", 3);
		h3.put("GPA", 2.0);
		h3.put("Age", 20);
		h3.put("DoB", checkDate("2010-04-12"));

		
		Hashtable h4 = new Hashtable();
		h4.put("ID", 4);
		h4.put("Name", "Ali");
		h4.put("GPA", 3.8);
		h4.put("Age", 12);
		h4.put("DoB", checkDate("2010-02-04"));

		
		Hashtable h6 = new Hashtable();
		h6.put("ID", 6);
		h6.put("Name", "Sara");
		h6.put("GPA", 2.2);
		h6.put("Age", 22);
		h6.put("DoB", checkDate("2010-12-11"));

		
		Hashtable h7 = new Hashtable();
		h7.put("ID", 7);
		h7.put("GPA", 3.4);
		h7.put("Name", "Kareem");
		h7.put("Age", 18);
		h7.put("DoB", checkDate("2010-12-11"));

		
		//--------------------------------------
		
		
		//-----------------------------------------------
		
		System.out.println("inserting 1...");
		insertIntoTable("Student", h1);
		//table.display();
		System.out.println("------------------------------------------------------------------------------------------------------");
		System.out.println("------------------------------------------------------------------------------------------------------");

		System.out.println("inserting 2...");
		insertIntoTable("Student", h2);
		//table.display();
		System.out.println("------------------------------------------------------------------------------------------------------");
		System.out.println("------------------------------------------------------------------------------------------------------");

		System.out.println("inserting 3...");
		insertIntoTable("Student", h3);
		//table.display();
		System.out.println("------------------------------------------------------------------------------------------------------");
		System.out.println("------------------------------------------------------------------------------------------------------");

		System.out.println("inserting 4...");
		insertIntoTable("Student", h4);
		//table.display();
		System.out.println("------------------------------------------------------------------------------------------------------");
		System.out.println("------------------------------------------------------------------------------------------------------");

		System.out.println("inserting 6...");
		insertIntoTable("Student", h6);
		//table.display();
		System.out.println("------------------------------------------------------------------------------------------------------");
		System.out.println("------------------------------------------------------------------------------------------------------");

		System.out.println("inserting 7...");
		insertIntoTable("Student", h7);
		//table.display();
		System.out.println("------------------------------------------------------------------------------------------------------");
		System.out.println("------------------------------------------------------------------------------------------------------");
		
	}
	
	public void testInsertAfterIndex() throws DBAppException{
		
		Table table = getTable("Student");
		
		Hashtable h8 = new Hashtable();
		h8.put("ID", 8);
		h8.put("Name", "Omar");
		h8.put("GPA", 3.6);
		h8.put("Age", 30);
		h8.put("DoB", checkDate("2010-02-05"));

		
		Hashtable h9 = new Hashtable();
		h9.put("ID", 9);
		h9.put("GPA", 2.1);
		h9.put("Name", "Youssef");
		h9.put("Age", 27);
		h9.put("DoB", checkDate("2010-02-05"));

		
		Hashtable h10 = new Hashtable();
		h10.put("ID", 10);
		h10.put("GPA", 2.3);
		h10.put("Name", "Malak");
		h10.put("Age", 11);
		h10.put("DoB", checkDate("2010-02-05"));

		
		Hashtable h11 = new Hashtable();
		h11.put("ID", 11);
		h11.put("Name", "Ahmed");
		h11.put("Age", 14);
		h11.put("GPA", 4.2);
		h11.put("DoB", checkDate("2010-02-05"));

		
		Hashtable h12 = new Hashtable();
		h12.put("ID", 12);
		h12.put("Name", "Malak");
		h12.put("GPA", 4.3);
		h12.put("Age", 11);
		h12.put("DoB", checkDate("2010-02-05"));

		
		
		System.out.println("inserting 8...");
		insertIntoTable("Student", h8);
		//table.display();
		System.out.println("------------------------------------------------------------------------------------------------------");
		System.out.println("------------------------------------------------------------------------------------------------------");

		
		System.out.println("inserting 9...");
		insertIntoTable("Student", h9);
		//table.display();
		System.out.println("------------------------------------------------------------------------------------------------------");
		System.out.println("------------------------------------------------------------------------------------------------------");

		
		System.out.println("inserting 12...");
		insertIntoTable("Student", h12);
		//table.display();
		System.out.println("------------------------------------------------------------------------------------------------------");
		System.out.println("------------------------------------------------------------------------------------------------------");

		
		Hashtable h5 = new Hashtable();
		h5.put("ID", 5);
		h5.put("Name", "Omar");
		h5.put("GPA", 2.2);
		h5.put("Age", 29);
		h5.put("DoB", checkDate("2010-02-05"));

		
		System.out.println("inserting 5...");
		insertIntoTable("Student", h5);
		//table.display();
		System.out.println("------------------------------------------------------------------------------------------------------");
		System.out.println("------------------------------------------------------------------------------------------------------");

		
		System.out.println("inserting 10");
		insertIntoTable("Student", h10);
	//	table.display();
		System.out.println("------------------------------------------------------------------------------------------------------");
		System.out.println("------------------------------------------------------------------------------------------------------");

		
		System.out.println("inserting 11");
		insertIntoTable("Student", h11);
		table.display();
		System.out.println("------------------------------------------------------------------------------------------------------");
		System.out.println("------------------------------------------------------------------------------------------------------");

		table.printIndices();
	}
	
	
	public void testDelete() throws DBAppException{
		
		Table table = getTable("Student");
		
		//        Multiple Conditions
		
//		Hashtable d1 = new Hashtable();
//		d1.put("Name", "Malak");
//		d1.put("GPA", 2.3);
//		d1.put("Age", 11);
//		
//		deleteFromTable("Student", d1);
		//table.display();
		
		//------------------------------------------------------
		
		//			Single Condition
		
//		Hashtable d2 = new Hashtable();
//		d2.put("Name", "Malak");
//		
//		deleteFromTable("Student", d2);
		//table.display();
//		
//		//--------------------------------------------------------
//		
		// 			includes pk
//		
//		Hashtable d3 = new Hashtable();
//		d3.put("ID", 10);
//		d3.put("Name", "Malak");
		
		//---------------------------------------------------------
		
		//			delete level in index
		
		Hashtable d4 = new Hashtable();
		d4.put("ID", 4);
		//d4.put("Name", "Malak");
		
		Hashtable d5 = new Hashtable();
		d5.put("ID", 11);
		Hashtable d6 = new Hashtable();
		d6.put("ID", 7);
		Hashtable d7 = new Hashtable();
		d7.put("ID", 12);
		
		deleteFromTable("Student", d4);
		deleteFromTable("Student", d5);
		deleteFromTable("Student", d6);
		deleteFromTable("Student", d7);
		
		//-----------------------------------------------------------
		
		//		delete all
//		Hashtable d8 = new Hashtable();
//		deleteFromTable("Student", d8);

		
		table.display();
		table.printIndices();
//		
//		
		
	}
	
	
	public void testUpdate() throws DBAppException{
		
		Table table = getTable("Student");
		
		//         UPDATE CORRECTLY
		
		System.out.println("update correctly");
		
		Hashtable update1 = new Hashtable();
		update1.put("Name", "Ali");
		update1.put("GPA", 3.9);
		
		updateTable("Student", "5", update1);
		table.display();
		
		//------------------------------------------------------------------
		
		//        INCORRECT DATA TYPES
		
//		System.out.println("update incorrect data type");
//		
//		Hashtable u2 = new Hashtable();
//		u2.put("Name", 20);
//		u2.put("GPA", 2.4);
//		
//		updateTable("Student", "2", u2);
//		table.display();
//		
//		//--------------------------------------------------------------------
		
		//       NOT IN RANGE
//		
//		System.out.println("update data not in range");
//		
//		Hashtable u3 = new Hashtable();
//		u3.put("Name", "Ali");
//		u3.put("GPA", 18.2);
//		
//		updateTable("Student", "5", u3);
//		table.display();
//		
//		//--------------------------------------------------------------------
		
		//             DUPLICATE PK
//		
//		System.out.println("update repeated pk");
//		
//		Hashtable u4 = new Hashtable();
//		u4.put("ID", 3);
//		u4.put("GPA", 2.4);
//		
//		updateTable("Student", "4", u4);
//		table.display();
//		
		
		
		//             NONEXISTENT RECORD
		
//		System.out.println("update nonexistent record");
//		
//		Hashtable u5 = new Hashtable();
//		u5.put("Name", "Salma");
//		u5.put("GPA", 3.4);
//		
//		updateTable("Student", "14", u5);
//		table.display();
		
		table.printIndices();
//		
		
	}
	
	
	
	
	public void testSelect() throws DBAppException{
		
		//	select with index
		
		SQLTerm[] arrSQLTerms; 
		arrSQLTerms = new SQLTerm[3]; 
		arrSQLTerms[0] = new SQLTerm();
		arrSQLTerms[0]._strTableName = "Student"; 
		arrSQLTerms[0]._strColumnName= "Name"; 
		arrSQLTerms[0]._strOperator = "="; 
		arrSQLTerms[0]._objValue = "Malak"; 
		
		arrSQLTerms[1] = new SQLTerm();
		arrSQLTerms[1]._strTableName = "Student"; 
		arrSQLTerms[1]._strColumnName= "GPA"; 
		arrSQLTerms[1]._strOperator = "="; 
		arrSQLTerms[1]._objValue = new Double(2.3); 
		
//		arrSQLTerms[2] = new SQLTerm();
//		arrSQLTerms[2]._strTableName = "Student"; 
//		arrSQLTerms[2]._strColumnName= "DoB"; 
//		arrSQLTerms[2]._strOperator = "="; 
//		arrSQLTerms[2]._objValue = checkDate("2010-03-24"); 
		
		arrSQLTerms[2] = new SQLTerm();
		arrSQLTerms[2]._strTableName = "Student"; 
		arrSQLTerms[2]._strColumnName= "Age"; 
		arrSQLTerms[2]._strOperator = "="; 
		arrSQLTerms[2]._objValue = 11; 
		
		String[]strarrOperators = new String[2]; 
		strarrOperators[0] = "AND"; 
		strarrOperators[1] = "AND";
		Iterator resultSet = selectFromTable(arrSQLTerms , strarrOperators); 
		
		System.out.println("Result Set");
		
		while(resultSet.hasNext()){
			System.out.println(resultSet.next());
		}
		
		
		//System.out.println(resultSet.toString());
	}
	
	
	public void testIndex() throws DBAppException{
		
		Table table = getTable("Student");
		
		String[] cols = {"Name", "GPA", "Age"};
		
		createIndex("Student", cols);
		
		String name = cols[0] + cols[1] + cols[2] + "Index";
		
		table = table.loadTable();
		
		Octree index = table.getIndex(name);
		index = index.loadIndex();
		
		index.display();
		
		index.saveIndex();
		
		table.saveTable();
		
	}
	
	
	public static void main(String[] args) throws DBAppException {
		
		DBApp db = new DBApp();
		
		System.out.println("--------------------------------------------------------------------");
		System.out.println("Testing Creation");
		System.out.println("--------------------------------------------------------------------");
		db.testCreate();
		
		System.out.println("--------------------------------------------------------------------");
		System.out.println("Testing Insertion");
		System.out.println("--------------------------------------------------------------------");
		db.testInsert2();
		
		System.out.println("--------------------------------------------------------------------");
		System.out.println("Testing Index");
		System.out.println("--------------------------------------------------------------------");
		db.testIndex();
//		
		System.out.println("--------------------------------------------------------------------");
		System.out.println("Testing Insertion After Index");
		System.out.println("--------------------------------------------------------------------");
		db.testInsertAfterIndex();
		
//		System.out.println("--------------------------------------------------------------------");
//		System.out.println("Testing Deletion");
//		System.out.println("--------------------------------------------------------------------");
//		db.testDelete();
////		
//		System.out.println("--------------------------------------------------------------------");
//		System.out.println("Testing Update");
//		System.out.println("--------------------------------------------------------------------");
//		db.testUpdate();
		
		System.out.println("--------------------------------------------------------------------");
		System.out.println("Testing Selection");
		System.out.println("--------------------------------------------------------------------");
		db.testSelect();
		
		
//		
		
		
		
//			
//			db.deleteFromTable("Student", new Hashtable());
//			table.display();
			
			//Hashtable t=new Hashtable();
			//t.put("Name", "Mariam");
			//db.updateTable("Student", "1.1",t );
			//System.out.println();
			//table.display();
			
			//db.insertIntoTable("Student", h2);
// 	} catch (DBAppException e) {
//			 //TODO Auto-gxenerated catch block
//			 e.printStackTrace();
//     }
		
		
		
	}
	
}