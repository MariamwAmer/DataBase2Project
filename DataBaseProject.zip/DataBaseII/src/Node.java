import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.Serializable;
import java.util.Date;
import java.util.Properties;
import java.util.Vector;


public class Node implements Serializable{
	
	private Node parent;
	private Node[] children;
	
//	private Vector<Page> pages = new Vector<Page>(); 	//hold reference to page containing tuple / Null if not leaf
//	private Vector CKs = new Vector();					//hold value of tuple CK/ Null if not leaf
//	private Vector<Point> points = new Vector<Point>();	//hold values of dimensions for each tuple in node

	private Vector<Key> keys = new Vector<Key>();
	
	private int maxNoOfKeys;		//from config file
	private int keyCount;
	
	private Point minValues;		//min boundary of node
	private Point maxValues;		//max boundary of node
	
	public Node(Point min, Point max){
		//parent is null --> root node
		
		Properties prop = new Properties();
		String fileName = "resources/DBApp.config";
		try (FileInputStream file = new FileInputStream(fileName)) {
		    prop.load(file);
		} catch (FileNotFoundException ex) {
	              
		} catch (IOException ex) {
		    
		}
		
		maxNoOfKeys=Integer.parseInt(prop.getProperty("MaximumEntriesinOctreeNode"));
		
		//maxNoOfKeys = 2;
		
		minValues = min;
		maxValues = max;
		
	}
	
	public Node(Node parent, Point min, Point max){
		
		this.parent = parent;
		
		Properties prop = new Properties();
		String fileName = "resources/DBApp.config";
		try (FileInputStream file = new FileInputStream(fileName)) {
		    prop.load(file);
		} catch (FileNotFoundException ex) {
	              
		} catch (IOException ex) {
		    
		}
		
		maxNoOfKeys=Integer.parseInt(prop.getProperty("MaximumEntriesinOctreeNode"));
		
		//maxNoOfKeys = 2;
		
		minValues = min;
		maxValues = max;
		
	}

	public Node getParent() {
		return parent;
	}

	public void setParent(Node parent) {
		this.parent = parent;
	}

//	public Vector<Page> getPages() {
//		return pages;
//	}
//
//	public void setPages(Vector<Page> pages) {
//		this.pages = pages;
//	}
//
//	public Vector getCKs() {
//		return CKs;
//	}
//
//	public void setCKs(Vector cKs) {
//		CKs = cKs;
//	}
//
//	public Vector<Point> getPoints() {
//		return points;
//	}
//
//	public void setPoints(Vector<Point> points) {
//		this.points = points;
//	}

	public Vector<Key> getKeys(){
		return keys;
	}
	
	public void setKeys(Vector<Key> keys){
		this.keys = keys; 
	}
	
	public int getMaxNoOfKeys() {
		return maxNoOfKeys;
	}

	public void setMaxNoOfKeys(int maxNoOfKeys) {
		this.maxNoOfKeys = maxNoOfKeys;
	}

	public Point getMinValues() {
		return minValues;
	}

	public void setMinValues(Point minValues) {
		this.minValues = minValues;
	}

	public Point getMaxValues() {
		return maxValues;
	}

	public void setMaxValues(Point maxValues) {
		this.maxValues = maxValues;
	}

	public Node[] getChildren() {
		return children;
	}

	public void setChildren(Node[] children) {
		this.children = children;
	}
	
	
	public boolean isFull(){
		return keys.size() == maxNoOfKeys;
	}
	
	public boolean isEmpty(){
		return keys.size() == 0;
	}
	
	
	public void splitNode() throws DBAppException{
		
		System.out.println("splitting node...");
		
		this.children = new Node[8];
		Object minX = minValues.getX();
		Object maxX = maxValues.getX();
		
		Object minY = minValues.getY();
		Object maxY = maxValues.getY();
		
		Object minZ = minValues.getZ();
		Object maxZ = maxValues.getZ();
		
		Object midX = getMid(minX, maxX);
		Object midY = getMid(minY, maxY);
		Object midZ = getMid(minZ, maxZ);
		
		children[0] = new Node(this, new Point(minX, minY, minZ), new Point(midX, midY, midZ));
		children[1] = new Node(this, new Point(minX, minY, midZ), new Point(midX, midY, maxZ));
		children[2] = new Node(this, new Point(minX, midY, minZ), new Point(midX, maxY, midZ));
		children[3] = new Node(this, new Point(minX, midY, midZ), new Point(midX, maxY, maxZ));
		children[4] = new Node(this, new Point(midX, minY, minZ), new Point(maxX, midY, midZ));
		children[5] = new Node(this, new Point(midX, minY, midZ), new Point(maxX, midY, maxZ));
		children[6] = new Node(this, new Point(midX, midY, minZ), new Point(maxX, maxY, midZ));
		children[7] = new Node(this, new Point(midX, midY, midZ), new Point(maxX, maxY, maxZ));
		
		
		
		for(int i = 0; i<keys.size(); i++){			//waza3na el keys 3al children
			
			Point values = keys.get(i).getPoint();
			
			Node n = Octree.findNode(this, values);
			
			n.getKeys().add(keys.get(i));
			
		}
		
		keys.clear();
	}
	
	
	public Object getMid(Object min, Object max){

		
		if(min instanceof Integer){
			return ((int)max + (int)min)/2;
		}
		
		if(min instanceof Double){
			return ((double)max + (double)min)/2;
		}
		
		if(min instanceof String){
			return Octree.getMiddleString((String)min, (String) max);
		}
		if(min instanceof Date){
			return Octree.getMiddleDate((Date)min, (Date) max);
		}
//		
		return null;
	}
	
	
	
	public Key getKey(Point p){
		
		System.out.println("checking if key exists....");
		
		for(int i = 0; i < keys.size(); i++){
			
			System.out.println(keys.get(i).getPoint());
			System.out.println(p);
			
			if(keys.get(i).getPoint().equals(p)){
				return keys.get(i);
			}
		}
		
		return null;
		
	}
	
	
	public void display(int depth){
		
		for(int i = 0; i< depth; i++){
			System.out.print("        ");
		}
		
		System.out.println("------------------");
		
		if(keys.size() == 0){
			
			for(int j = 0; j < depth; j++){
				System.out.print("        ");
			}
			
			if(parent == null){
				System.out.println("<Root Node>");
			}
			
			else if(children != null){
				System.out.println("<Internal Node>");
			}
			
			else{
				System.out.println("<Empty Leaf Node>");
			}
			
			
		}
		
		for(int i = 0; i < keys.size(); i++){
			
			for(int j = 0; j < depth; j++){
				System.out.print("        ");
			}
			System.out.println(keys.get(i));
		}
		
		for(int j = 0; j < depth; j++){
			System.out.print("        ");
		}
		System.out.println("------------------ \n");
		
		if(children != null){
			for(int i = 0; i < children.length; i++){
				for(int j = 0; j < depth + 1; j++){
					System.out.print("        ");
				}
				System.out.println("Node " + i + " " + children[i].getMinValues() + " - " + children[i].getMaxValues());
				children[i].display(depth+1);
			}
		}
	}
	
	
	
}
