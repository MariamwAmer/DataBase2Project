import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Hashtable;
import java.util.Vector;

public class Table implements Serializable {
	private String tableName;
	private String clusterKey;
	private Hashtable<String, String> htblColNameTypes;
	private Hashtable<String, String> htblColNameMin;
	private Hashtable<String, String> htblColNameMax;
	private String tablePath;
	private Vector<Page> pages; // = new Vector<Page>();
	
	private Vector<Octree> indices;

	public Table(String tablename, String clusterkey,
			Hashtable<String, String> nameandatttypes,
			Hashtable<String, String> htblColNameMin,
			Hashtable<String, String> htblColNameMax) {
		this.tableName = tablename;
		this.clusterKey = clusterkey;
		this.htblColNameTypes = nameandatttypes;
		this.htblColNameMin = htblColNameMin;
		this.htblColNameMax = htblColNameMax;
		pages = new Vector<Page>();
		tablePath = "resources/data/" + tableName + "/" + tableName + ".ser";
		
		indices = new Vector<Octree>();

	}

	public static void serialize(Table t) {
		try {
			String filePath = "resources/data/" + t.tableName + "/"
					+ t.tableName + ".ser";
			File f = new File(filePath);
			boolean exists = false;
			if (f.exists())
				exists = true;

			FileOutputStream fileOut = new FileOutputStream(filePath);
			ObjectOutputStream out = new ObjectOutputStream(fileOut);
			out.writeObject(t);
			out.close();
			fileOut.close();
			if (!exists)
				System.out.printf("Serialized table is saved in " + filePath
						+ "\n\n");

		} catch (IOException i) {
			i.printStackTrace();
		}
	}

	// public static void deserialize(Table t){
	// try {
	// String filePath = "resources/data/" + t.tableName + "/" + t.tableName +
	// ".ser";
	//
	// FileInputStream fileIn = new FileInputStream(filePath);
	// ObjectInputStream in = new ObjectInputStream(fileIn);
	// t = (Table) in.readObject();
	// in.close();
	// fileIn.close();
	// //return t;
	// } catch (IOException i) {
	// i.printStackTrace();
	// return ;
	// } catch (ClassNotFoundException c) {
	// System.out.println("Table class not found");
	// c.printStackTrace();
	// return ;
	// }
	// }

	public static Table deserialize(File serializedFile) {
		Table table;
		if (!serializedFile.exists() || !serializedFile.canRead()) {
			return null;
		}
		try {
			// use buffering
			InputStream file = new FileInputStream(serializedFile);
			InputStream buffer = new BufferedInputStream(file);
			ObjectInput input = new ObjectInputStream(buffer);
			try {
				// deserialize the List
				table = (Table) input.readObject();
			} finally {
				input.close();
			}
		} catch (ClassNotFoundException ex) {
			ex.printStackTrace();
			return null;
		} catch (IOException ex) {
			ex.printStackTrace();
			return null;
		}

		return table;
	}

	public String getTablename() {
		return tableName;
	}

	public void setTablename(String tablename) {
		this.tableName = tablename;
	}

	public String getClusterkey() {
		return clusterKey;
	}

	public void setClusterkey(String clusterkey) {
		this.clusterKey = clusterkey;
	}

	public Hashtable<String, String> getHtblColNameTypes() {
		return htblColNameTypes;
	}

	public void setHtblColNameTypes(Hashtable<String, String> nameandatttypes) {
		this.htblColNameTypes = nameandatttypes;
	}

	public Hashtable<String, String> getHtblColNameMin() {
		return htblColNameMin;
	}

	public void setHtblColNameMin(Hashtable<String, String> htblColNameMin) {
		this.htblColNameMin = htblColNameMin;
	}

	public Hashtable<String, String> getHtblColNameMax() {
		return htblColNameMax;
	}

	public void setHtblColNameMax(Hashtable<String, String> htblColNameMax) {
		this.htblColNameMax = htblColNameMax;
	}

	public Vector<Page> getPages() {
		return pages;
	}

	public void setPages(Vector tuplesintable) {
		this.pages = tuplesintable;
	}

	public String getTablePath() {
		return tablePath;
	}

	public void setTablePath(String tablePath) {
		this.tablePath = tablePath;
	}
	
	

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public String getClusterKey() {
		return clusterKey;
	}

	public void setClusterKey(String clusterKey) {
		this.clusterKey = clusterKey;
	}

	public Vector<Octree> getIndices() {
		return indices;
	}

	public void setIndices(Vector<Octree> indices) {
		this.indices = indices;
	}



	public void display() {
		System.out.println("Displaying table....");
		Table t = this.loadTable();

		// System.out.println(t.getPages());
		// String s = "";
		System.out.println("---------------------------------------------");
		System.out.println(tableName);
		System.out.println("---------------------------------------------");
		// System.out.println(t.getPages().size());

		for (int i = 0; i < t.getPages().size(); i++) {
			// System.out.println(t.getPages().get(i).getPageName());
			Page p = t.getPages().get(i).loadPage();
			System.out.println("Page " + (i + 1) + ": " + p.display() + "\n");
			p.savePage();
		}
		System.out.println("---------------------------------------------");

		t.saveTable();

		// return s;
	}

	public Table loadTable() {
		Table t = deserialize(new File(this.getTablePath()));
		System.out.println(tableName + " Table loaded \n");
		return t;
	}

	public void saveTable() {
		serialize(this);
		System.out.println(tableName + " Table saved \n");

	}
	
	public Octree getIndex(String name) throws DBAppException{
		for(int i = 0; i < indices.size(); i++){
			if(indices.get(i).getName().equals(name)){
				//System.out.println(indices.get(i).getName());
				return indices.get(i);
			}
		}
		
		throw new DBAppException("Index Not Found");
	}
	
	public int getPageIndex(String pageName){
		for(int i = 0; i < pages.size(); i++){
			if(pages.get(i).getPageName().equals(pageName)){
				//System.out.println(indices.get(i).getName());
				return i;
			}
		}
		
		return -1;
	}
	
	public void deleteFromIndices(Page p, Hashtable tuple) throws DBAppException{
		for(int i = 0; i < indices.size(); i++){
			Octree index = indices.get(i);
			index = index.loadIndex();
			
			index.deleteTuple(p, tuple);
			
			index.saveIndex();

		}
	}
	
	
	//updates key when tuple's page changes
	public void updateIndices(Page p, Hashtable tuple) throws DBAppException{		
		
		for(int i = 0; i < indices.size(); i++){
			Octree index = indices.get(i);
			index = index.loadIndex();
			
			index.updateKeys(p.getPageName(), tuple);
			
			index.saveIndex();

		}
		
	}
	
	
	//updates tuples attributes in index
	public void updateIndexTuple(Page p, Hashtable oldTuple, Hashtable newTuple) throws DBAppException{		
		
		for(int i = 0; i < indices.size(); i++){
			Octree index = indices.get(i);
			index = index.loadIndex();
			
			index.deleteTuple(p, oldTuple);
			index.insert(p, newTuple);
			
			index.saveIndex();

		}
	}
	
	public void printIndices(){
		Table t = this.loadTable();
		for(int i = 0; i < t.getIndices().size(); i++){
			Octree index = t.getIndices().get(i);
			index.display();
		}
		
		t.saveTable();
	}

}