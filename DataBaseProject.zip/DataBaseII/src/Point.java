import java.io.Serializable;
import java.util.Date;
import java.util.Hashtable;
import java.util.Vector;


public class Point implements Serializable{

	//Point[] childPoints;
	//public Object x, y, z;
	
	//values of 3 dimensions for the node
	private Object x;
	private Object y;
	private Object z;
	
	public Point(){
		x = -1;
		y = -1;
		z = -1;
		
	}

	public Point(Object _x, Object _y, Object _z) {
		// TODO Auto-generated constructor stub
		this.x = _x;
		this.y = _y;
		this.z = _z;
		//this.childPoints = new Point[8];
	}

	public Object getX() {
		return x;
	}

	public void setX(Object x) {
		this.x = x;
	}

	public Object getY() {
		return y;
	}

	public void setY(Object y) {
		this.y = y;
	}

	public Object getZ() {
		return z;
	}

	public void setZ(Object z) {
		this.z = z;
	}
	
	public String compareTo(Point p){
		
		String s = "";
		
		if(p.getX() instanceof NULL){
			s += "X";
		}
		else{
			if(compareTo(p.getX(), this.x) < 0)
				s += "0";
			else
				s += "1";
		}
		
		if(p.getY() instanceof NULL){
			s += "X";
		}
		else{
			if(compareTo(p.getY(), this.y) < 0)
				s += "0";
			else
				s += "1";
		}
		
		if(p.getZ() instanceof NULL){
			s += "X";
		}
		else{
			if(compareTo(p.getZ(), this.z) < 0)
				s += "0";
			else
				s += "1";
		}
		
		return s;
	}
	
//	public static void main(String[] args) {
//		Point p = new Point(new NULL(), )
//	}
	
	
	public boolean equals(Point p){
		
		return p.getX().equals(x) && p.getY().equals(y) && p.getZ().equals(z);
	}
	
	public void toLowerCase(){
		if(x instanceof String)
			x = ((String) x).toLowerCase();
		if(y instanceof String)
			y = ((String) y).toLowerCase();
		if(z instanceof String)
			z = ((String) z).toLowerCase();
	}
	
	
	public static int compareTo(Object o1, Object o2){
		
		System.out.println(o1+ "   "+ o2);
		
		//Class type = o1.getClass();
		//System.out.println(o1.getClass() + "      " + o2.getClass());
		
		if(o1 instanceof String && o2 instanceof String){
			return ((String)o1).toLowerCase().compareTo(((String)o2).toLowerCase());
		}
		
		else if(o1 instanceof Date && o2 instanceof Date){
			return ((Date)o1).compareTo((Date)o2);
		}
		else if(o1 instanceof Integer && o2 instanceof Integer){
			return ((Integer)o1) - ((Integer)o2);
		}
		else {
			return ((Double)o1).compareTo((Double)o2);
		}
		
	}
	
	
	
	public String toString(){
		return "(" + x + ", " + y + ", " + z + ")";
	}
	
}
