import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;



public class Octree implements Serializable{

	private Table table;
	private Node root;
	//private Octree[] childNodes;
	//boolean parent;
	private int depth = 0;
	
	private String col1;
	private String col2;
	private String col3;
	
	private String name;
	
	private String path;
	
//	private Object minX;
//	private Object maxX;
//	private Object minY;
//	private Object maxY;
//	private Object minZ;
//	private Object maxZ;
	
	//private Point minValues;	//point of the form (x,y,z) with MIN values for dimensions from csv
	//private Point maxValues;	//point of the form (x,y,z) with MAX values for dimensions from csv
	

	/**
	 * Parameterized Constructor.
	 * 
	 * @param x
	 * @param Point.
	 * 
	 */
//	public Octree(Point p) {
//		this.root = p;
//	}

	/**
	 * Default.
	 */
	public Octree() {		//create an empty octree
		root = null;		//only has root point which is empty
	}

	public Octree(Table table, Point mins, Point maxs, String[] columns) {	//const takes table and names of cols to index
		root = new Node(mins, maxs);
		this.table = table;
		
		col1 = columns[0];
		col2 = columns[1];
		col3 = columns[2];
		
		name = col1+col2+col3+"Index";
		//minValues = mins;
		//maxValues = maxs;
		
		path = "resources/data/" + table.getTablename() + "/" + name + ".ser";
	}
		 
	
	
	
	public Table getTable() {
		return table;
	}

	public void setTable(Table table) {
		this.table = table;
	}

	public Node getRoot() {
		return root;
	}

	public void setRoot(Node root) {
		this.root = root;
	}

	public int getDepth() {
		return depth;
	}

	public void setDepth(int depth) {
		this.depth = depth;
	}

	public String getCol1() {
		return col1;
	}

	public void setCol1(String col1) {
		this.col1 = col1;
	}

	public String getCol2() {
		return col2;
	}

	public void setCol2(String col2) {
		this.col2 = col2;
	}

	public String getCol3() {
		return col3;
	}

	public void setCol3(String col3) {
		this.col3 = col3;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public void insert(Page page, Hashtable tuple) throws DBAppException{
		
		System.out.println("inserting " + tuple.get(table.getClusterkey()) + "\n");
		
		String ck = table.getClusterkey();
		
		Object x = tuple.get(col1);
		Object y = tuple.get(col2);
		Object z = tuple.get(col3);
		
//		if(x instanceof String)
//			x = ((String)x).toLowerCase();
//		if(y instanceof String)
//			y = ((String)y).toLowerCase();
//		if(z instanceof String)
//			z = ((String)z).toLowerCase();
		
		Point values = new Point(x,y,z);
		values.toLowerCase();
		
		//if()
		
		Node nodeToInsert = findNode(root, values);
		System.out.println("finding node...");
		
		Key k = nodeToInsert.getKey(values);
		
		if(k == null){		//if key doesn't exist create new key
			k = new Key(page, tuple.get(ck), values);
			
			while(nodeToInsert.isFull()){
				nodeToInsert.splitNode();
				//depth++;
				nodeToInsert = findNode(nodeToInsert, values);
			}
			
			nodeToInsert.getKeys().add(k);

		}
		else{		//if key exists add to duplicates hashtable
			k.insertTuple(page.getPageName(), tuple.get(ck));
		}
		
		 System.out.println(tuple.get(table.getClusterkey()) + " inserted \n");

	}
	
	
	public void deleteTuple(Page page, Hashtable tuple) throws DBAppException{
			
		Point values = new Point(tuple.get(col1), tuple.get(col2), tuple.get(col3));
		values.toLowerCase();
		
		String ckName = table.getClusterkey();
		
		System.out.println("Deleting " + tuple.get(ckName) + " From Index " + name + "...");

		
		Node n = findNode(root, values);
		
		Key key = n.getKey(values);
		
		if(key == null){
			throw new DBAppException("Key Not Found");
		}
		
		System.out.println(page);
		System.out.println(key.getPageTuples());
		
		Vector tuplesForPage = key.getPageTuples().get(page.getPageName());
		
		tuplesForPage.remove(tuple.get(ckName));
		
		if(tuplesForPage.isEmpty()){
			key.getPageTuples().remove(page.getPageName());
		}
		
		if(key.getPageTuples().isEmpty()){
			n.getKeys().remove(key);
		}
		
		
		if(n.isEmpty()){
			Node parent = n.getParent();
			
			if(parent != null){		//node is not the root node
				boolean allEmpty = true;
				for(int i = 0; i < parent.getChildren().length; i++){
					if(!parent.getChildren()[i].isEmpty()){
						allEmpty = false;
						break;
					}
				}
				
				if(allEmpty){
					parent.setChildren(null);	//delete level
				}
			}
		}
		
		System.out.println(tuple.get(ckName) + " Deleted From Index " + name + "...");
		
	}
	
//	public void updateIndex(Page p, Hashtable oldTuple, Hashtable newTuple) throws DBAppException{
//		
//		deleteTuple(p, oldTuple);
//		insert(p, newTuple);
//		
////		Point values = new Point(oldTuple.get(col1), oldTuple.get(col2), oldTuple.get(col3));
////		values.toLowerCase();
//		
//		
//	}
	
	
	public void updateKeys(String pageName, Hashtable tuple) throws DBAppException{
		
		Point values = new Point(tuple.get(col1), tuple.get(col2), tuple.get(col3));
		values.toLowerCase();
		
		String ckName = table.getClusterkey();
		Object ckValue = tuple.get(ckName);
		
		Node n = findNode(root, values);
		
		Key k = n.getKey(values);
		
		if(k != null){
			
			if(k.contains(ckValue)) {
				
//				Hashtable pageTuples = k.getPageTuples();
				
				String page = k.getPageName(ckValue);
				
				if(!page.equals(pageName)){
					
					k.getPageTuples().get(page).remove(ckValue);
					
					if(k.getPageTuples().get(page).isEmpty()){
						k.getPageTuples().remove(page);
					}
					
					k.insertTuple(pageName, ckValue);
				}
			}
		}
	}
	
	public Hashtable<String, Vector> getTuples(Hashtable<String, Object> conditions) throws DBAppException{
		
		Object col1Value = conditions.get(col1);
		Object col2Value = conditions.get(col2);
		Object col3Value = conditions.get(col3);
		
		Point values = new Point(col1Value, col2Value, col3Value);
		values.toLowerCase();
		
		
		Node n = findNode(root, values);
		
		Key key = n.getKey(values);
		
		if(key == null){
			throw new DBAppException("Key Not Found");
		}
		
		//n.getKeys().remove(key);
		
//		if(n.isEmpty()){
//			Node parent = n.getParent();
//			
//			if(parent != null){		//node is not the root node
//				boolean allEmpty = true;
//				for(int i = 0; i < parent.getChildren().length; i++){
//					if(!parent.getChildren()[i].isEmpty()){
//						allEmpty = false;
//						break;
//					}
//				}
//				
//				if(allEmpty){
//					parent.setChildren(null);	//delete level
//				}
//			}
//		}
		
		return key.getPageTuples();
	}
	
	
	public Hashtable<String, Vector> searchExact(Point values) throws DBAppException{
		
		Node n = findNode(root, values);
		
		Key k = n.getKey(values);
		
		if(k != null)
			return k.getPageTuples();
		
		return null;
		
	}
	
	
	
	
	public static Node findNode(Node node, Point values) throws DBAppException{
	
//		if(node.getMinValues().compareTo(values).equals("000") || node.getMaxValues().compareTo(values).equals("111"))
//			throw new DBAppException("Values out of index range");
		
		if(node.getChildren() == null){
			return node;
		}
		
		else{
			
			Point min = node.getMinValues();
			Point max = node.getMaxValues();
			
//			System.out.println(min);
//			System.out.println(max);
//			
//			System.out.println(min.getX().getClass());
//			System.out.println(min.getY().getClass());
//			System.out.println(min.getZ().getClass());
//
//			System.out.println(max.getX().getClass());
//			System.out.println(max.getY().getClass());
//			System.out.println(max.getZ().getClass());

			
			Object midX = getMid(min.getX(), max.getX());
			Object midY = getMid(min.getY(), max.getY());
			Object midZ = getMid(min.getZ(), max.getZ());
			
			Point midpoints = new Point(midX, midY, midZ);
			
//			System.out.println(midpoints);
//			System.out.println(values);
//			
			String s = midpoints.compareTo(values);
			
			switch(s){
				case "000": return findNode(node.getChildren()[0], values);
				case "001": return findNode(node.getChildren()[1], values);
				case "010": return findNode(node.getChildren()[2], values);
				case "011": return findNode(node.getChildren()[3], values);
				case "100": return findNode(node.getChildren()[4], values);
				case "101": return findNode(node.getChildren()[5], values);
				case "110": return findNode(node.getChildren()[6], values);
				case "111": return findNode(node.getChildren()[7], values);
				
				/*
				 * x00
				 * x01
				 * x10
				 * x11
				 * 0x0
				 * 0x1
				 * 1x0
				 * 1x1
				 * 00x
				 * 01x
				 * 10x
				 * 11x
				 * 
				 * 
				 * xx0
				 * xx1
				 * x0x
				 * x1x
				 * 0xx
				 * 1xx
				 * 
				 * getNode With Smaller no of keys
				 */
				
				default: return null;
			}
		}
	}
	
	
	public static Object getMid(Object min, Object max){

//		System.out.println(min);
//		System.out.println(max);
//		
//		System.out.println(min.getClass());
//		System.out.println(max.getClass());
		
		Object middle = null;

		
		if(min instanceof Integer){
			middle = ((int)max + (int)min)/2;
		}
		
		if(min instanceof Double){
			middle = ((double)max + (double)min)/2;
		}
		
		if(min instanceof String){
			middle = getMiddleString((String)min, (String) max);
		}
		if(min instanceof Date){
			middle = getMiddleDate((Date)min, (Date) max);
		}
//		
		//System.out.println(middle);
		
		return middle;
	}
	
	
	// Function to print the string at
    // the middle of lexicographically
    // increasing sequence of strings from S to T
    static String getMiddleString(String s, String t)
    {
    	
    	System.out.println("finding middle string...");
    	s = s.toLowerCase();
    	t = t.toLowerCase();
    	
    	int N = Math.max(s.length(), t.length());
    	
    	if(s.length() != t.length()){
	    	
	    	for(int i = 0; i < N; i++){
	    		
	    		if(i >= s.length()){
	    			s += t.charAt(i);
	    		}
	    		
	    		if(i >= t.length()){
	    			t += s.charAt(i);
	    		}
	    	}
    	}
    	
        // Stores the base 26 digits after addition
        int[] a1 = new int[N + 1];		//create array for s
 
        for (int i = 0; i < N; i++) {		//fill array bel ASCII bta3 s + t
            a1[i + 1] = (int)s.charAt(i) - 97
                        + (int)t.charAt(i) - 97;
        }
 
        // Iterate from right to left
        // and add carry to next position
        for (int i = N; i >= 1; i--) {			//make sure characters are alphabet
            a1[i - 1] += (int)a1[i] / 26;
            a1[i] %= 26;
        }
 
        // Reduce the number to find the middle
        // string by dividing each position by 2
        for (int i = 0; i <= N; i++) {
 
            // If current value is odd,
            // carry 26 to the next index value
            if ((a1[i] & 1) != 0) {
 
                if (i + 1 <= N) {
                    a1[i + 1] += 26;
                }
            }
 
            a1[i] = (int)a1[i] / 2;
        }
        
        String res = "";
 
        for (int i = 1; i <= N; i++) {
            res += ((char)(a1[i] + 97));
        }
        return res;
    }
    
    
    public static Date getMiddleDate(Date d1, Date d2){
    	
    	System.out.println(d1 + "   " + d2);
    	
    	
    	LocalDate date1 = d1.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
    	LocalDate date2 = d2.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
    	
    	long numDays = ChronoUnit.DAYS.between(date1, date2);
    	LocalDate median = date1.plusDays(numDays / 2L);
    	
    	Date date = Date.from(median.atStartOfDay(ZoneId.systemDefault()).toInstant());
    	
    	
    	return date;
   
    }
    
    
    @SuppressWarnings("deprecation")
	public static void main(String[] args) throws DBAppException {
//		System.out.println(getMid("a", "nmzzzz"));
//		System.out.println(getMid(2.85, 5.0));
//		System.out.println(getMid(2,25));
    	Date d1 = DBApp.checkDate("2023-05-15");
    	Date d2 = DBApp.checkDate("2023-06-17");
    	
    	System.out.println(getMiddleDate(d1,d2));
	}
	
    
  
	public void display(){
		
		System.out.println("Displaying Index");
		
		Octree index = this.loadIndex();
		
		System.out.println("---------------------------------------------");
		System.out.println(index.getName());
		System.out.println("--------------------------------------------- \n");
		
		//System.out.println(index.getName() + "\n");
		
		System.out.println("Root");
		index.getRoot().display(0);
		
		System.out.println("--------------------------------------------- \n");

		
		index.saveIndex();

	}
    
	
	public static void serialize(Octree o){
		try {
			
			File f = new File(o.getPath());
			 boolean exists = false;
			 if(f.exists())
				 exists = true;
			
			//String filePath = "resources/data/" + p.getTable().getTablename() + "/" + p.getPageName() + ".ser";
	         FileOutputStream fileOut =
	         new FileOutputStream(o.getPath());
	         ObjectOutputStream out = new ObjectOutputStream(fileOut);
	         out.writeObject(o);
	         out.close();
	         fileOut.close();
	         if(!exists)
	        	 System.out.printf("Serialized index is saved in " + o.getPath() + "\n");
	      } catch (IOException i) {
	         i.printStackTrace();
	      }
	}
	
	public static Octree deserialize(File serializedFile) {
	    Octree octree;
	    if (!serializedFile.exists() || !serializedFile.canRead()) {
	        return null;
	    }
	    try {
	        //use buffering
	        InputStream file = new FileInputStream(serializedFile);
	        InputStream buffer = new BufferedInputStream(file);
	        ObjectInput input = new ObjectInputStream(buffer);
	        try {
	            //deserialize the List
	            octree = (Octree) input.readObject();
	        } finally {
	            input.close();
	        }
	    } catch (ClassNotFoundException ex) {
	        ex.printStackTrace();
	        return null;
	    } catch (IOException ex) {
	        ex.printStackTrace();
	        return null;
	    }

	    return octree;
	}
	
	public Octree loadIndex(){
		Octree o = deserialize(new File(this.getPath()));
		System.out.println(table.getTablename() + " " + name + " loaded \n");
		return o;

	}
	
	public void saveIndex(){
		serialize(this);
		System.out.println(table.getTablename() + " " + name + " saved \n");

	}
	
	public void createOctree(){
		table.getIndices().add(this);
		//System.out.println(table.getPages());
		serialize(this);
		System.out.println(table.getTablename() + " " + name + " created \n");
	}
	
	
	public boolean hasCol(String colName){
		return colName.equals(col1) || colName.equals(col2) || colName.equals(col3);
	}
	
	public void clearIndex(){
		root.setChildren(null);
	}
	
//	
//	public void print_tree() {
//
//		for (int k = 0; k < depth; k++) {
//			System.out.print("   ");
//		}
//
//		root.display(depth);
//
//		if (root.getChildren() != null) {
//			for (int j = 0; j < 8; j++) {
//				for (int k = 0; k < depth; k++) {
//					System.out.print("   ");
//				}
//				root.getChildren()[j].display(j);
//			}
//		} else {
//			for (int j = 0; j < 8; j++) {
//				this.children[j].print_tree();
//			}
//		}
//	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
    
/*	
		
		//this.root = p;
	
	
	public int i = 0;

	/**
	 * Add the points to the octree.
	 * 
	 * @param x
	 * @param y
	 * @param z           
	 * 
	 * @return boolean indicating whether the point was added or not.
	 /

	public boolean add_nodes(Comparable x, Comparable y, Comparable z) {

		boolean success = false;

		if (this.i < 8) {
			if (compare(x, y, z)) {
				if (root.getChildren() == null) {
					System.out.println("Root is null" + x + " " + y + " " + z);
				}

				//this.root.getChildren()[i] = new Point(x, y, z);
				this.i++;
				success = true;
			}
		}

		else if (this.childNodes == null) {

			this.create_nodes_of_nodes(x, y, z);

			for (int j = 0; j < 8; j++) {
				int tempx = this.root.x.compareTo(root.childPoints[j].x);
				int tempy = this.root.y.compareTo(root.childPoints[j].y);
				int tempz = this.root.z.compareTo(root.childPoints[j].z);

				int checker = compareValues(tempx, tempy, tempz);

				this.childNodes[checker].add_nodes(root.childPoints[j].x,
						root.childPoints[j].y, root.childPoints[j].z);

			}
			root.childPoints = null;

			double tempx = this.root.x.compareTo(x);
			double tempy = this.root.y.compareTo(y);
			double tempz = this.root.z.compareTo(z);
			int checker = compareValues(tempx, tempy, tempz);
			this.childNodes[checker].add_nodes(x, y, z);
			// this.i=0;
		}

		else {

			if (childNodes != null) {
				int checker = compareValues(x, y, z);
				childNodes[checker].add_nodes(x, y, z);

			}
		}

		return success;
	}

	/**
	 * Compare the values for which we need to add to the octant.
	 * 
	 * @param x
	 * @param y
	 * @param z           
	 * 
	 * @return the index(0-7) to which we need to insert
	 * the point in the octant
	 */
	
	/*
	public int compareValues(double x, double y, double z) {

		if (x > 0 && y > 0 && z > 0)
			return 0;
		else if (x > 0 && y > 0 && z < 0)
			return 1;
		else if (x > 0 && y < 0 && z > 0)
			return 2;
		else if (x > 0 && y < 0 && z < 0)
			return 3;
		else if (x < 0 && y > 0 && z > 0)
			return 4;
		else if (x < 0 && y > 0 && z < 0)
			return 5;
		else if (x < 0 && y < 0 && z > 0)
			return 6;
		else
			return 7;

	}

	/**
	 * Compare the values for range check -2.0 to 2.0.
	 * 
	 * @param x
	 * @param y
	 * @param z           
	 * 
	 * @return boolean indicating the bound check.
	 */
	
	/*
	public boolean compare(Comparable x, Comparable y, Comparable z) {
		if (x <= 2.0 && x >= -2.0) {
			if (y <= 2.0 && y >= -2.0) {
				if (z <= 2.0 && z >= -2.0) {
					return true;
				}
			}
		}
		return true;
	}

	// dimension/2 power depth

	public double makeDimensions(double dimensions) {
		return (this.dimensions) / (2 ^ depth);
	}

	/**
	 * Create nodes of nodes.
	 * 
	 * @param x
	 * @param y
	 * @param z           
	 * 
	 * @return the boolean indicating success 
	 */
	/*
	public boolean create_nodes_of_nodes(Comparable x, Comparable y, Comparable z) {

		this.childNodes = new Octree[8];
		boolean success = false;

		/*this.childNodes[0] = new Octree(this.dimensions / 2, new Point(
				this.root.x + dimensions / 2, this.root.y + dimensions / 2,
				this.root.z + dimensions / 2));

		this.childNodes[1] = new Octree(this.dimensions / 2, new Point(
				this.root.x + dimensions / 2, this.root.y + dimensions / 2,
				this.root.z - dimensions / 2));

		this.childNodes[2] = new Octree(this.dimensions / 2, new Point(
		
		
				this.root.x + dimensions / 2, this.root.y - dimensions / 2,
				this.root.z + dimensions / 2));

		this.childNodes[3] = new Octree(this.dimensions / 2, new Point(
				this.root.x + dimensions / 2, this.root.y - dimensions / 2,
				this.root.z - dimensions / 2));

		this.childNodes[4] = new Octree(this.dimensions / 2, new Point(
				this.root.x - dimensions / 2, this.root.y + dimensions / 2,
				this.root.z + dimensions / 2));

		this.childNodes[5] = new Octree(this.dimensions / 2, new Point(
				this.root.x - dimensions / 2, this.root.y + dimensions / 2,
				this.root.z - dimensions / 2));

		this.childNodes[6] = new Octree(this.dimensions / 2, new Point(
				this.root.x - dimensions / 2, this.root.y - dimensions / 2,
				this.root.z + dimensions / 2));

		this.childNodes[7] = new Octree(this.dimensions / 2, new Point(
				this.root.x - dimensions / 2, this.root.y - dimensions / 2,
				this.root.z - dimensions / 2));
*/
		
		
	/*	
		
		
		
		return success;

	}

	/**
	 * Printing the tree using breadth first search.
	 /
	public void print_tree() {

		int depth = (int) (Math.log(2 / dimensions) / Math.log(2));

		for (int k = 0; k < depth; k++) {
			System.out.print("   ");
		}

		System.out.println("(" + root.x + ", " + root.y + ", " + root.z + ")"
				+ "  -- " + dimensions);

		if (this.childNodes == null) {
			for (int j = 0; j < i; j++) {
				for (int k = 0; k < depth; k++) {
					System.out.print("   ");
				}
				System.out.println("  *  (" + this.root.childPoints[j].x + ", "
						+ this.root.childPoints[j].y + ", "
						+ this.root.childPoints[j].z + ")");
			}
		} else {
			for (int j = 0; j < i; j++) {
				this.childNodes[j].print_tree();
			}
		}
	}
	*/

	/*
	 * The main method
	 */
}