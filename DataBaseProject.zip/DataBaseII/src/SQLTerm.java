
public class SQLTerm {

	String _strTableName = "";
	String _strColumnName = "";
	String _strOperator = "";
	Object _objValue = null;
	
	public SQLTerm(){
		
	}
	
	public SQLTerm(String tableName, String colName, String op, Object val){
		 _strTableName = tableName;
		 _strColumnName = colName;
		 _strOperator = op;
		 _objValue = val;
		
	}
	
}
